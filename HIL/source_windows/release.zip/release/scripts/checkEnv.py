import sys
import time
try:
    import torch
    import monai
    import nibabel
    import numpy
    import scipy
    print("成功获取环境，相关软件包安装检验通过")
    time.sleep(2)
    exit(0)
except ImportError as e:
    sys.stderr.write(f"缺失python包:{e.name}，请选择其他环境或手动安装\n")
    exit(1)
