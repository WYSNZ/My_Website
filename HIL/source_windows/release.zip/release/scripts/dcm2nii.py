from ntpath import isdir
import dcm2niix
import argparse
import os

def parse_args():
    parser=argparse.ArgumentParser()
    parser.add_argument("--dataset_root_dir",required=True)
    parser.add_argument("--output_dir",required=True)
    parser.add_argument("--output_name",required=True)
    return parser.parse_args()

def trans(dataset_root_dir:str,output_dir:str,output_name:str):
    datasets=[]
    for folder in os.listdir(dataset_root_dir):
        src=os.path.join(dataset_root_dir,folder)
        if not os.path.isdir(src):
            continue
        datasets.append(src)
        if not os.path.exists(os.path.join(output_dir,folder)):
            os.makedirs(os.path.join(output_dir,folder), exist_ok=True)
    print(f"共发现{len(datasets)}文件")
    for dataset in datasets:
        dcm2niix.main([
            "-z","y",
            "-f",output_name,
            "-o",os.path.join(output_dir,os.path.basename(dataset)),
            dataset
        ])

def main():
    args=parse_args()
    trans(args.dataset_root_dir,args.output_dir,args.output_name)

if __name__=="__main__":
    main()