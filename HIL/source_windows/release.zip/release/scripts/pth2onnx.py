import torch
import json
from unet3d.models.build import fetch_model_by_name
from torch.onnx import TrainingMode
import onnx
import argparse
import shutil
import os


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config_path", required=True)
    parser.add_argument("--model_path", required=True)
    parser.add_argument("--output_onnx_path", required=True)
    parser.add_argument("--template_exe_dir", required=True)
    return parser.parse_args()

def convert_pth_to_onnx(config_path, model_path, output_onnx_path):
    """
    根据配置文件将 .pth 模型转换为 ONNX 格式
    """
    # 加载配置
    with open(config_path, 'r') as f:
        config = json.load(f)
    
    model_config = config["model"]
    
    # 创建模型
    model = fetch_model_by_name(
        model_config["name"],
        spatial_dims=model_config["spatial_dims"],
        in_channels=model_config["in_channels"],
        out_channels=model_config["out_channels"],
        strides=model_config["strides"],
        filters=model_config["filters"],
        kernel_size=model_config["kernel_size"],
        upsample_kernel_size=model_config["upsample_kernel_size"]
    )
    
    # 加载权重
    state_dict = torch.load(model_path, map_location=torch.device('cpu'))
    model.load_state_dict(state_dict)
    model.eval()
    model.float()
    
    # # 强制所有子模块进入 eval 模式（包括 Instance Norm）
    # for module in model.modules():
    #     if hasattr(module, 'training'):
    #         module.training = False
    
    # # 再次确认 Instance Norm 的状态
    # for name, module in model.named_modules():
    #     if 'instance' in name.lower() or 'InstanceNorm' in type(module).__name__:
    #         module.training = False
    #         print(f"Set {name} to eval mode")
    
    # 创建示例输入 (batch, channels, depth, height, width)
    batch_size = 1
    channels = model_config["in_channels"]  # 3
    depth, height, width = config["dataset"]["desired_shape"]  # 128, 128, 128
    dummy_input = torch.randn(batch_size, channels, depth, height, width)
    
    # 导出 ONNX
    torch.onnx.export(
        model,
        dummy_input,
        output_onnx_path,
        export_params=True,
        opset_version=17,
        do_constant_folding=True,
        input_names=['input'],
        output_names=['output'],
        training=TrainingMode.EVAL,
        dynamic_axes={
            'input': {0: 'batch_size', 2: 'depth', 3: 'height', 4: 'width'},
            'output': {0: 'batch_size', 2: 'depth', 3: 'height', 4: 'width'}
        }
    )
    
    print(f"转换完成: {output_onnx_path}")
    
    # 验证 ONNX 模型

    onnx_model = onnx.load(output_onnx_path)
    onnx.checker.check_model(onnx_model)
    print("ONNX 模型验证通过！")
    
    # # 使用 ONNX Runtime 测试并比较输出
    # import onnxruntime as ort
    # import numpy as np
    
    # session = ort.InferenceSession(output_onnx_path)
    # input_name = session.get_inputs()[0].name
    
    # # 使用相同的输入测试 PyTorch 和 ONNX
    # with torch.no_grad():
    #     torch_output = model(dummy_input).numpy()
    # onnx_output = session.run(None, {input_name: dummy_input.numpy()})[0]
    
    # # 比较差异
    # diff = np.abs(torch_output - onnx_output)
    # print(f"\n===== 转换验证 =====")
    # print(f"PyTorch 输出形状: {torch_output.shape}")
    # print(f"ONNX 输出形状: {onnx_output.shape}")
    # print(f"最大差异: {diff.max():.6e}")
    # print(f"平均差异: {diff.mean():.6e}")
    
    # if diff.max() < 1e-4:
    #     print("✓ 转换成功！PyTorch 和 ONNX 输出基本一致")
    # else:
    #     print("✗ 警告：PyTorch 和 ONNX 输出存在较大差异！")
    
    # return output_onnx_path

if __name__ == "__main__":
    args = parse_args()
    output_dir=os.path.dirname(args.output_onnx_path)
    
    if not os.path.exists(output_dir):
        os.makedirs(output_dir, exist_ok=True)
        print(f"创建输出目录: {output_dir}")

    convert_pth_to_onnx(
        config_path=args.config_path,
        model_path=args.model_path,  # 替换为你的模型路径
        output_onnx_path=args.output_onnx_path
    )
    print(f"模型已保存到: {args.output_onnx_path}")

    shutil.copy(args.config_path,os.path.join(output_dir, "config.json"))

    print(f"配置文件已复制到: {os.path.join(output_dir, 'config.json')}")

    shutil.copytree(args.template_exe_dir, output_dir, dirs_exist_ok=True)

    print(f"模板可执行文件已复制到: {output_dir}")
    print("转换完成！")
