import gc
import nibabel
import os
import argparse
import numpy as np

def parse_args():
    parser=argparse.ArgumentParser()
    parser.add_argument("--output_dir",required=True)
    parser.add_argument("--dataset_root_dir",required=True)
    parser.add_argument("--segmentation_name",required=True)
    args=parser.parse_args()
    return args

def trans_single(output_dir:str,ori_dataset:str,seg_name:str):
    dataset_basename=os.path.normpath(ori_dataset).split(os.path.sep)[-1]
    if not os.path.exists(output_dir):
        exit(1)
    raw_output=os.path.join(output_dir,"predictions",dataset_basename+".nii.gz")
    if not os.path.exists(raw_output):
        exit(2)
    if not os.path.exists(ori_dataset):
        exit(3)
    dest_output=os.path.join(ori_dataset,seg_name+".nii.gz")

    img=nibabel.load(raw_output)
    data=img.get_fdata()
    labels=np.argmax(data,axis=-1)
    labels_img=nibabel.Nifti1Image(labels.astype(np.uint8),img.affine)
    nibabel.save(labels_img,dest_output)
    img.uncache()
    gc.collect()


    if os.path.exists(raw_output):
        os.remove(raw_output)

def trans(output_dir:str,dataset_root_dir:str,seg_name:str):
    datasets=[]
    for folder in os.listdir(dataset_root_dir):
        src=os.path.join(dataset_root_dir,folder)
        if not os.path.isdir(src):
            continue
        if not os.path.exists(os.path.join(src,seg_name+".nii.gz")):
            continue
        datasets.append(src)
    for dataset in datasets:
        trans_single(output_dir,dataset,seg_name)



def main():
    args=parse_args()
    trans(args.output_dir,args.dataset_root_dir,args.segmentation_name) //输出、数据集文件夹(到id级)、分割文件名称

if __name__=="__main__":
    main()

# str1="D:/itk/test.exe"
# str2="D:\\itk\\test.exe"
# # print(os.path.normpath(str1).split(os.path.sep))
# print(os.path.normpath(str2))
# print(os.path.sep)