import os
import glob
import json
import argparse
import nibabel
import numpy as np

config=dict()

def str2bool(value:str):
    if value.lower() in {'true',"True"}:
        return True
    elif value.lower() in {'false','False'}:
        return False
    else:
        raise argparse.ArgumentTypeError(f'boolean type error:{value}')
    
def parse_args():
    parser=argparse.ArgumentParser();
    parser.add_argument("--model_name",required=True)
    parser.add_argument("--in_channels",required=True,type=int)
    parser.add_argument("--out_channels",required=True,type=int)
    parser.add_argument("--depth",required=True,type=int)
    parser.add_argument("--deep_supervision",required=True,type=str2bool)
    parser.add_argument("--spatial_dims",required=True,type=int)
    parser.add_argument("--independent_input",required=True,type=str2bool)

    parser.add_argument("--optimizer_name",required=True)
    parser.add_argument("--lr_rate",required=True,type=int)

    parser.add_argument("--loss_name",required=True)
    parser.add_argument("--include_bg",required=True,type=str2bool)
    parser.add_argument("--act_func",required=True)

    parser.add_argument("--enable_cross_validation",required=True,type=str2bool)
    parser.add_argument("--n_folds",required=False)
    parser.add_argument("--seed",required=False,type=int)

    parser.add_argument("--scheduler_name",required=True)
    parser.add_argument("--patience",required=True,type=int)
    parser.add_argument("--factor",required=True,type=float)
    parser.add_argument("--min_lr_rate",required=True,type=int)

    parser.add_argument("--dataset_name",required=True)
    parser.add_argument("--shape_x",required=True,type=int)
    parser.add_argument("--shape_y",required=True,type=int)
    parser.add_argument("--shape_z",required=True,type=int)
    parser.add_argument("--labels",required=True)
    parser.add_argument("--setup_label_hierarchy",required=True,type=str2bool)
    parser.add_argument("--normalization",required=True)
    parser.add_argument("--channel_wise",required=True,type=str2bool)
    parser.add_argument("--nonzero",required=True,type=str2bool)
    parser.add_argument("--resample",required=True,type=str2bool)
    parser.add_argument("--crop_foreground",required=True,type=str2bool)

    parser.add_argument("--batch_size",required=True,type=int)
    parser.add_argument("--validation_batch_size",required=False,type=int)
    parser.add_argument("--amp",required=True,type=str2bool)
    parser.add_argument("--early_stopping_patience",required=True,type=int)
    parser.add_argument("--n_epochs",required=True,type=int)
    parser.add_argument("--save_every_n_epochs",required=True,type=int)
    parser.add_argument("--save_last_n_models",required=True,type=int)
    parser.add_argument("--save_best",required=True,type=str2bool)

    parser.add_argument("--img_dir",required=True)
    parser.add_argument("--img_name",required=True)
    parser.add_argument("--label_name",required=True)
    parser.add_argument("--gen_com_label",required=True,type=str2bool)

    parser.add_argument("--output_dir",required=True)

    return parser.parse_args()

def create_config(args)->None:
    model_config=dict()
    model_config["name"]=args.model_name
    model_config["in_channels"]=args.in_channels
    model_config["out_channels"]=args.out_channels
    model_config["spatial_dims"]=args.spatial_dims
    model_config["deep_supervision"]=args.deep_supervision
    depth_calcu(args.depth,model_config)
    config["model"]=model_config

    optimizer_config=dict()
    optimizer_config["name"]=args.optimizer_name
    optimizer_config["lr"]=10**(-args.lr_rate)
    config["optimizer"]=optimizer_config

    loss_config=dict()
    loss_config["name"]=args.loss_name
    loss_config["include_background"]=args.include_bg
    loss_config[args.act_func]=True
    config["loss"]=loss_config

    if args.enable_cross_validation:
        cross_config=dict()
        cross_config["n_folds"]=args.n_folds
        cross_config["random_seed"]=args.seed
        config["cross_validation"]=cross_config
    
    scheduler_config=dict()
    scheduler_config["name"]=args.scheduler_name
    scheduler_config["patience"]=args.patience
    scheduler_config["factor"]=args.factor
    scheduler_config["min_lr"]=10**(-args.min_lr_rate)
    config["scheduler"]=scheduler_config

    dataset_config=dict()
    dataset_config["name"]=args.dataset_name
    dataset_config["desired_shape"]=list()
    dataset_config["desired_shape"].append(args.shape_x)
    dataset_config["desired_shape"].append(args.shape_y)
    dataset_config["desired_shape"].append(args.shape_z)
    labels=args.labels.replace('，',',').split(',')
    dataset_config["labels"]=[]
    for label in labels:
        dataset_config["labels"].append((int)(label))
    dataset_config["setup_label_hierarchy"]=args.setup_label_hierarchy
    dataset_config["normalization"]=args.normalization
    nor_kwargs=dict()
    nor_kwargs["channel_wise"]=args.channel_wise
    nor_kwargs["nonzero"]=args.nonzero
    dataset_config["normalization_kwargs"]=nor_kwargs
    dataset_config["resample"]=args.resample
    dataset_config["crop_foreground"]=args.crop_foreground
    config["dataset"]=dataset_config

    training_config=dict()
    training_config["batch_size"]=args.batch_size
    training_config["validation_batch_size"]=args.validation_batch_size
    training_config["amp"]=args.amp
    training_config["early_stopping_patience"]=args.early_stopping_patience if args.early_stopping_patience != 0 else None
    training_config["n_epochs"]=args.n_epochs
    training_config["save_every_n_epochs"]=args.save_every_n_epochs if args.save_every_n_epochs !=0 else None
    training_config["save_last_n_models"]=args.save_last_n_models if args.save_last_n_models !=0 else None
    training_config["save_best"]=args.save_best
    config["training"]=training_config

    config["training_filenames"]=list()
    config["prediction_filenames"]=list()
    config["rest_filenames"]=list()
    label_name=args.label_name
    if args.gen_com_label:
        gen_combined_label(args.img_dir,args.label_name)
        label_name="combined_label"
    search_image_and_label(args.img_dir,args.img_name,label_name,config,args.independent_input)

    with open(args.output_dir,'w') as op:
        json.dump(config,op,indent=4)
    
def depth_calcu(depth:int,model_config:dict)->None:
    strides=[[1,1,1]]
    strides+=[[2,2,2]]*(depth-1)

    filters=[64]
    for i in range(depth-1):
        filters.append((int)(filters[i]*1.5))
    
    kernel_size=[[3,3,3]]*depth

    upsample_kernel_size=[[2,2,2]]*(depth-1)

    model_config["strides"]=strides
    model_config["filters"]=filters
    model_config["kernel_size"]=kernel_size
    model_config["upsample_kernel_size"]=upsample_kernel_size

def gen_combined_label(root_dir:str,label_name:str)->None:
    files=label_name.replace('，',',').split(',')
    files=[f+".nii.gz" for f in files]
    for sub_dir in sorted(glob.glob(os.path.join(root_dir,"*"))):
        missing=False
        for file in files:
            if not os.path.exists(os.path.join(sub_dir,file)):
                missing=True
                break
        if missing:
            continue
        first_label_obj=nibabel.load(os.path.join(sub_dir,files[0]))
        first_label=np.asanyarray(first_label_obj.dataobj)
        combined_label=np.zeros_like(first_label,dtype=np.int8)
        for file in files:
            label_obj=nibabel.load(os.path.join(sub_dir,file))
            label=np.asanyarray(label_obj.dataobj)
            unique_label=np.unique(label)
            for val in unique_label:
                if val>0:
                    combined_label[label==val]=val
        combined_nii=nibabel.Nifti1Image(combined_label,first_label_obj.affine)
        combined_path=os.path.join(sub_dir,"combined_label.nii.gz")
        nibabel.save(combined_nii,combined_path)

def search_image_and_label(root_dir:str,img_name:str,combined_label_name:str,config:dict,is_independent:bool)->None:
    files=img_name.replace('，',',').split(',')
    for sub_dir in sorted(glob.glob(os.path.join(root_dir,"*"))):
        filename=dict()
        filename["image"]=list()
        if not os.path.isdir(sub_dir):
            continue
        cur_files=os.listdir(sub_dir)
        cur_files=[f.split(".nii.gz")[0] for f in cur_files]
        if not is_independent:
            missing=False
            for file in files:
                if file not in cur_files:
                    missing=True
                    break
            if not missing:
                for file in files:
                    filename["image"].append(os.path.normpath(os.path.join(sub_dir,file+".nii.gz")))
                # if os.path.exists(os.path.join(sub_dir,combined_label_name+".nii.gz")):
                #     filename["label"]=os.path.normpath(os.path.join(sub_dir,combined_label_name+".nii.gz"))
                #     config["training_filenames"].append(filename)
                # else:
                config["rest_filenames"].append(filename)
        else:
            for file in files:
                if file in cur_files:
                    filename = dict()
                    filename["image"] = [os.path.normpath(os.path.join(sub_dir, file + ".nii.gz"))]
                    config["rest_filenames"].append(filename)

                
                 

            
def main():
    args=parse_args()
    create_config(args)

if __name__=="__main__":
    main()
            
        

# root_dir="D:\itksnap\CTmask"
# print(os.path.join("D:\itksnap\CTmask",sorted(glob.glob(os.path.join(root_dir,"*")))[0]))
    
    
# config=dict()
# config["training_filenames"]=[]
# root_dir="D:\itksnap\CTmask"
# name="40,70,vnc"
# label_name="breSeg"
# search_image_and_label(root_dir,name,label_name,config)
# print(config)

# root_dir="D:\itksnap\HIL\dataset"
# lebel_name="breSeg,mask"
# gen_combined_label(root_dir,lebel_name)