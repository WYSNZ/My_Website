#pragma once

#include <QDialog>
#include "ui_environmentControl.h"
#include <QFileDialog>
#include <QProcess>
#include <QTimer>
#include <QCloseEvent>
#include <QProgressDialog>
#include <QMessageBox>
#include <QSettings>
#include "constants.h"
class environmentControl : public QDialog
{
    Q_OBJECT

public:
    explicit environmentControl(QWidget *parent = nullptr,QString cache_dir=QCoreApplication::applicationDirPath()+"/cache.ini");
    ~environmentControl();
    Ui::environmentControl* ui;
    QString python_env ="";
    QString itk_snap_path = "";
private:
    void btn_browse_env_clicked();
    void btn_browse_itk_clicked();
    void btn_ok_clicked();
    void load_cache(QString dir);
    void btn_skip_clicked();
protected:
    void closeEvent(QCloseEvent* event) override;
signals:
};
