#pragma once

#include <QDialog>
#include "ui_exportIPP.h"
#include <QFileDialog>
#include <QMessageBox>
#include <QFileInfo>
#include <QDir>
#include <QSettings>
#include <QProcess>
#include <QTimer>


class exportIPP: public QDialog
{
    Q_OBJECT

public:
    explicit exportIPP(QWidget *parent = nullptr, QString python = "",QString project_dir = "",bool independent=true);
    ~exportIPP();
private:
    Ui::exportIPP* ui;
    QString python;
    QString project_dir;
    bool independent=true;

    void init();
    void on_btn_browse_output_dir_clicked();
    void on_btn_ok_clicked();
    void on_btn_cancel_clicked();
signals:
};
