#pragma once

#include <QDialog>
#include "ui_manageDatasets.h"
#include <QDir>
#include <QSqlQuery>
#include <QJsonDocument>
#include <QJsonArray>
#include <QJsonObject>
#include <QJsonValue>
#include <QMessageBox>
#include "constants.h"

class manageDatasets: public QDialog
{
    Q_OBJECT

public:
    explicit manageDatasets(QWidget* parent = nullptr,QString dataset_root_dir="",QStringList img_dirs=QStringList(),QString label_dir="", QString project_dir="",bool independent_input=false);
    ~manageDatasets();
private:
    Ui::manageDatasets* ui;
    QString dataset_root_dir;
    QStringList img_dirs;
    QString label_dir;
    QString project_dir;
    bool independent_input;

    void load_all_datasets();
    bool check_imgs(QString folder_path);
    void add_img_nodes(QTreeWidgetItem* root, QString dataset);
    bool check_dataset_is_added(QString dataset, QString img_dir);
    void on_check_changed(QTreeWidgetItem* item,int column);
    void handle_child_change(QTreeWidgetItem* child, bool checked);
    void update_parent_state(QTreeWidgetItem* child);
    void update_parent_state();
    void handle_dependent_input(QTreeWidgetItem* item);
    void add_dataset(QString name, QString img_dir);
    void delete_dataset(QString name);

    void on_btn_refresh_clicked();
    void on_btn_ok_clicked();
signals:
};
