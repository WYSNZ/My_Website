#pragma once

#include <QDialog>
#include "ui_generateConfig.h"
#include <QFileDialog>
#include <QDebug>
#include <QFileInfo>
#include <QMessageBox>
#include <QProcess>
#include <QProgressDialog>
#include <QSettings>
#include "constants.h"

#include "manageDatasets.h"

class generateConfig : public QDialog
{
    Q_OBJECT

public:
    explicit generateConfig(QWidget *parent = nullptr,QString python_env="",QString cache_dir="");
    ~generateConfig();
    Ui::generateConfig* ui;
    QStringList args;
    void load_cache(QString dir);
private:
    
    void connect_signals();
    void get_model_args();
    void get_optimizer_args();
    void get_loss_args();
    void get_cross_validation_args();
    void get_scheduler_args();
    void get_dataset_args();
    void get_training_args();
    void get_dataset_dir();
    void get_output_dir();
    void btn_ok_pressed();
    void btn_cancel_pressed();

    void run_script();
    void on_process_started(QProgressDialog* msg_box);
    void on_process_finished(int code, QProcess::ExitStatus status, QProgressDialog* msg_box);

    void dump_cache(QString dir);

    void set_value_from_cache(QString key, QString val);
    void advanced_settings(bool if_show);
    void btn_show_all_settings_clicked(Qt::CheckState is_checked);

    bool input_validation();
    void on_browse_images_clicked();
    void on_browse_label_clicked();

    void on_independent_input_checked(Qt::CheckState state);

    QString error_msg;
    QString python_exe = "";
    QString cache_dir = "";
signals:
    void send_config_dir(QString dir,QString label_name);
};

class datasets : public QDialog {
    Q_OBJECT
public:
    explicit datasets(QWidget* parent=nullptr,QString window_title="",QString dataset_root_dir="",QString added_img_files="",QString added_label_files="");
    ~datasets();
    Ui::manageDatasets* d_ui;
private:
    QString dataset_root_dir;
    QStringList added_img_files;
    QStringList added_label_files;
    QSet<QString> search_nii_files(QString dataset_root_dir);
    void init();
    void on_btn_ok_clicked();
    void on_btn_refresh_clicked();
signals:
    void send_datasets(QString datasets);
};