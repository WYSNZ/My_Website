#pragma once

#include <QDialog>
#include "ui_dcm2nii.h"
#include <QFileDialog>
#include <QMessageBox>
#include "constants.h"
#include <QProcess>
#include <QTimer>

class dcm2nii: public QDialog
{
    Q_OBJECT

public:
    explicit dcm2nii(QWidget *parent = nullptr,QString python="");
    ~dcm2nii();
private:
    Ui::dcm2nii* ui;
    QString python;
    void on_btn_browse_dcm_dir_clicked();
    void on_btn_browse_output_dir_clicked();
    void on_btn_ok_clicked();
    void on_btn_cancel_clicked();
signals:
};
