#pragma once

#include <QMainWindow>
// #include "generateConfig.h"
#include <QJsonArray>
#include <QJsonObject>
#include <QJsonDocument>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QFile>
#include <QTreeWidget>

#include "itemDoubleClick.h"
#include <QTimer>
#include <QThread>
#include <QInputDialog>
#include "startTraining.h"
#include "startPrediction.h"

#include "environmentControl.h"

#include "constants.h"
#include <QHash>
#include <QFontDialog>

#include "changeConfig.h"
// #include "addDatasets.h"
#include "manageDatasets.h"

#include <QDirIterator>

#include "dcm2nii.h"
#include "exportIPP.h"


QT_BEGIN_NAMESPACE
namespace Ui {
    class MainWindow;
}
QT_END_NAMESPACE
typedef struct {
    int id;
    QString name;
    QString img_dir;
    QString label_dir;
    int annotated;
} dataset_item;
class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    explicit MainWindow(QWidget* parent = nullptr, QString project_name = "", QString cache_dir = "");
    ~MainWindow();
    bool load_cache();
    void init_database();
private:
    Ui::MainWindow* ui;
    void connect_signals();
    void on_action_changeConfig_triggered();
    void analyze_json_file();

    void insert_dataset(QJsonArray& files);
    std::optional<dataset_item> query_dataset(QString name);
    void update_annotated(int id, int annotated);
    void update_dataset_list();
    void on_annotated_changed(QTreeWidgetItem* item, int column);
    // void move_to_training(const QString& name, const QString& labelPath);
    // void move_to_rest(const QString& name);
    // void on_load_from_files_triggered();
    void on_item_double_clicked(QTreeWidgetItem* item, int column);
    // void on_set_selected_as_pre_clicked();

    void update_env_info_browser(QString key, QString val);
    void init_msg();
    void on_btn_strt_training_clicked();
    void on_btn_stop_training_clicked();
    void on_btn_start_pre_clicked();
    void on_btn_stop_pre_clicked();
    void run_after_process_script(QString pre_output_dir, QString original_dataset);

    void get_py_env();
    void dump_cache();

    void on_action_clear_terminal_triggered();
    void on_action_font_triggered();
    void on_action_about_triggered();

    void on_btn_check_annotated_clicked();

    void update_dataset_status(QTreeWidgetItem* item, int status);

    void update_progress_bar(int total, int current);
    void capture_n_epoches(QString output, int& n_epochs);
    void capture_current_epoch(QString output, int& batch_size, int& current);
    void capture_prediction_progress(QString output, int& total, int& current);
    void closeEvent(QCloseEvent* event) override;

    void on_btn_manage_dataset_clicked();
    void on_dataset_right_clicked(const QPoint& pos);

    void json_a_to_b(const QString& label_a, const QString& label_b, const QString& name);
    void json_a_to_b(const QString& label_a, const QString& label_b, const QString& name, const QString& label_path);

    void filter_datasets(const QString& text);
    void clear_search_result();
    void block_dataset_change();
    void recover_dataset_change();

    void copy_models();
    bool copy_files(const QString& src, const QString& des);

    void on_action_dcm_2_nii_triggered();
    void on_action_export_ipp_triggered();

    QBrush not_annotated;
    QBrush under_training;
    QBrush annotated;
    QString config_dir;
    QString label_name;
    changeConfig* config;

    QProcess* process_tr;
    QProcess* process_pre;

    QString python_exe;
    QString itk_dir;
    QHash<QString, QString> env_info;
    QString cache_dir = "";
    QString project_name = "default_name";
    int index_msg = 0;

    bool independent_input;


    void on_back_project_manage_clicked();

    void debug();
signals:
    void back_project_manage();
};
