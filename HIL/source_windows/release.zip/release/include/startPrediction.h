#pragma once

#include <QDialog>
#include "ui_startPrediction.h"
#include <QFileDialog>
#include <QMessageBox>
#include <QCloseEvent>

class startPrediction : public QDialog
{
    Q_OBJECT

public:
    explicit startPrediction(QWidget *parent = nullptr,QString project_dir="");
    ~startPrediction();
    Ui::startPrediction* ui;
    QString project_dir = "";
    QString output_dir = "";
    QString model_dir="";
    int ngpus=0;
    int nthreads=0;
private:
    void btn_browse_output_clicked();
    void btn_browse_model_clicked();
    void btn_ok_clicked();
    void btn_cancel_clicked();
    void auto_set_model();
    void auto_set_output_dir();
protected:
    void closeEvent(QCloseEvent* event) override;
signals:
};
