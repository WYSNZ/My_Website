#pragma once

#include <QDialog>
#include "ui_changeConfig.h"
#include <QFile>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QMessageBox>
#include <QDebug>
#include "constants.h"
#include <QSettings>


class changeConfig: public QDialog
{
    Q_OBJECT

public:
    explicit changeConfig(QWidget *parent = nullptr,QString json_file="",QString cache_dir="");
    ~changeConfig();
    
private:
    Ui::changeConfig* ui;
    void load_json(QString json);
    QString json;
    void btn_ok_clicked();
    void btn_cancel_clicked();
    void btn_show_all_settings_clicked(Qt::CheckState is_checked);
    void advanced_settings(bool is_show);
    QString cache_dir;
signals:
};
