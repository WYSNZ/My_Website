#ifndef CONSTANTS_H
#define CONSTANTS_H

#include <QString>
#include <QObject>
namespace messageConstants
{
    const QString ERROR_TITLE = QObject::tr("错误");
    const QString WARNING_TITLE = QObject::tr("警告");
    const QString INFO_TITLE = QObject::tr("提示");
    const QString SUCCESS_TITLE = QObject::tr("完成");

    const QString FILE_NOT_FOUND = QObject::tr("文件不存在:");
    const QString DATABASE_ERROR = QObject::tr("数据库操作失败:");
    const QString CONFIG_ERROR = QObject::tr("配置文件错误:");
    const QString PROCESS_TERMINATED = QObject::tr("进程已终止:");
    const QString VALIDATION_FAIL = QObject::tr("输入验证失败");

    const QString TRAINING_COMPLETE = QObject::tr("训练完成");
    const QString PREDICTION_COMPLETE = QObject::tr("预测完成");
    const QString ENV_CHECK_PASSED = QObject::tr("环境检测通过");
    const QString ENV_CHECK_FAILED = QObject::tr("环境检测未通过");
    
    // 用户操作提示
    const QString SELECT_DATASET_FIRST = QObject::tr("请先选择数据集");
    const QString CHECK_CONFIG_CONTENT = QObject::tr("请检查配置文件内容");
    const QString SELECT_VALID_FILE = QObject::tr("请选择有效的文件");
    const QString ENV_SETUP_INCOMPLETE = QObject::tr("环境配置未完成");
}

namespace DialogTitles {
    const QString SELECT_JSON_FILE = QObject::tr("选择JSON文件");
    const QString SELECT_DATASET_DIR = QObject::tr("选择数据集文件夹");
    const QString SELECT_OUTPUT_DIR = QObject::tr("选择输出目录");
    const QString SELECT_PYTHON_ENV = QObject::tr("选择Python解释器");
    const QString SELECT_ITKSNAP = QObject::tr("选择ITK-SNAP");
    const QString SELECT_MODEL_FILE = QObject::tr("选择模型文件");
}

#endif
