#pragma once

#include <QMainWindow>
#include "ui_projectManage.h"
#include <QCloseEvent>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QMessageBox>
#include "constants.h"
#include "newProject.h"
#include <QDir>
#include "environmentControl.h"

#include <QTranslator>
#include <QLocale>
#include "changeLang.h"

class projectManage : public QMainWindow
{
    Q_OBJECT

public:
    explicit projectManage(QWidget* parent = nullptr);
    ~projectManage();
    static bool load_lang(QString path);
private:
    Ui::projectManage* ui;
    void create_database();
    void create_cache_folder();
    void on_action_newProject_triggered();
    void dump_cache(QString python, QString itk);
    void refresh_projects_table();
    void on_item_double_clicked(QTableWidgetItem* item);
    void clear_database_connnection();

    void on_item_right_clicked(const QPoint& pos);
    void delete_project(QTableWidgetItem* item);

    void on_change_lang_triggered();


protected:
    void closeEvent(QCloseEvent* event) override;
signals:
    void projectSelected(QString name,QString cache_dir);
};
