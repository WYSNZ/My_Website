#pragma once

#include <QDialog>
#include "ui_itemDoubleClick.h"
#include <QFileInfo>
#include <QTreeWidget>
#include <QMessageBox>
#include <QDesktopServices>
#include <QUrl>
#include <QProcessEnvironment>
#include <QDir>

class itemDoubleClick: public QDialog
{
    Q_OBJECT

public:
    explicit itemDoubleClick(QWidget *parent = nullptr,QString img_dir="",QString label_dir="",QString label_name="",QString itk_dir="");
    ~itemDoubleClick();
    Ui::itemDoubleClick* ui;
    QString _img_dir;
    QString _label_dir;
    QString _label_name;
    QString _itk_dir;
private:
    void init();
    void on_item_double_clicked(QTreeWidgetItem* item, int column);
    QString search_label_files(QString path);
    void on_btn_refresh_clicked();
signals:
};
