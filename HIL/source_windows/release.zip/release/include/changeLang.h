#pragma once

#include <QDialog>
#include "ui_changeLang.h"

class changeLang: public QDialog
{
    Q_OBJECT

public:
    explicit changeLang(QWidget *parent = nullptr);
    ~changeLang();
private:
    Ui::changeLang* ui;
    void on_btn_ok_clicked();
    void on_btn_cancel_clicked();
signals:
    void lang_change(QString lang);
};
