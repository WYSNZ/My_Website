#pragma once

#include <QDialog>
#include "ui_newProject.h"
#include <QMessageBox>
#include "constants.h"
#include "generateConfig.h"
#include <QInputDialog>
class newProject : public QDialog
{
    Q_OBJECT

public:
    explicit newProject(QWidget *parent = nullptr,QString python_dir="",QString cache_dir="");
    ~newProject();
    QString projectName = "";
    QString config="";
    QString label_name = "";
private:
    Ui::newProject* ui;
    void btn_ok_clicked();
    void btn_cancel_clicked();
    void btn_new_config_clicked();
    void btn_choose_exist_clicked();


    QString python_dir="";
    QString cache_dir = "";
signals:
};
