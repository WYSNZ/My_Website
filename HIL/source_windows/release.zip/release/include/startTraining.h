#pragma once

#include <QDialog>
#include "ui_startTraining.h"
#include <QFileDialog>
#include <QMessageBox>
#include <QCloseEvent>

class startTraining : public QDialog {
    Q_OBJECT

public:
    explicit startTraining(QWidget* parent = nullptr,QString project_dir="");
    ~startTraining();
    Ui::startTraining* ui;
    int ngpus = 0;
    int nthreads = 0;
    QString project_dir="";
    QString output_dir = "";


private:
    void on_ok_clicked();
    void on_cancel_clicked();
    void on_browse_clicked();
    void auto_set_output_dir();
protected:
    void closeEvent(QCloseEvent* event) override;
signals:
};
