# HIL - 人在回路医学图像标注平台

基于Qt 6.9.1开发的3D医学图像分割训练平台，集成3DUnet深度学习模型，提供数据集管理、模型训练、预测一站式解决方案。

***

## 目录

1. [功能特点](#功能特点)
2. [环境要求](#环境要求)
3. [数据集结构](#数据集结构)
4. [快速开始](#快速开始)
5. [使用流程](#使用流程)
6. [项目结构](#项目结构)
7. [关于本项目](#关于本项目)

***

## 功能特点

- 📊 **项目管理** - 多项目创建、切换、删除
- 🧠 **深度学习** - 集成3DUnet模型训练与预测
- 📁 **数据集管理** - 空闲集/训练集/预测集分类管理
- 🖥️ **医学图像查看** - 集成ITK-SNAP
- ⏳ **进度提示** - 训练/预测过程实时显示

***

## 环境要求

### 必需软件

| 软件       | 版本要求  | 说明       |
| -------- | ----- | -------- |
| Python   | 3.8+  | 深度学习运行环境 |
| Qt       | 6.9.1 | 桌面UI框架   |
| ITK-SNAP* | 3.8+  | 医学图像查看器  |
| CMake    | 3.16+ | 构建工具     |

*ITK-SNAP可以替换为你想要的任何可以打开分割文件的软件


### Python依赖

```bash
pip install -r requirements.txt
```

## 数据集结构

⚠️ **数据集结构一致性是系统正常工作的关键**

### 目录结构要求

每个数据集文件夹必须遵循以下命名规范和文件结构：

```
{dataset_root}/
├── {dataset_name_1}/
│   ├── {image_name_1}.nii.gz     # 医学图像文件
│   ├── {image_name_2}.nii.gz     # 可多个图像
│   └── {label_name}.nii.gz       # 标签文件（训练必需）
├── {dataset_name_2}/
│   ├── {image_name_1}.nii.gz
│   ├── {image_name_2}.nii.gz
│   └── {label_name}.nii.gz
└── ...
```

### 配置文件参数

在生成配置时需要指定以下关键参数：

| 参数           | 说明           | 示例            |
| ------------ | ------------ | ------------- |
| `img_dir`    | 数据集根目录       | `C:/path/to/your/dataset` |
| `img_name`   | 图像文件名（不含扩展名） | `image`       |
| `label_name` | 标签文件名（不含扩展名） | `label`       |

### 正确的文件名示例

假设配置参数为：`img_name = image`，`label_name = label`

✅ **正确的数据集结构：**

```
D:/medical_data/
├── patient_001/
│   ├── image.nii.gz    ✅ 图像文件
│   └── label.nii.gz    ✅ 标签文件
├── patient_002/
│   ├── image.nii.gz
│   └── label.nii.gz
└── patient_003/
    ├── image.nii.gz
    └── label.nii.gz    ✅ 用于训练
```


### 数据集状态说明

| 状态  | 数据库annotated值 | config.json位置          | 说明       |
| --- | ------------- | ---------------------- | -------- |
| 空闲集 | 0             | `rest_filenames`       | 可用于训练或预测 |
| 训练集 | 1             | `training_filenames`   | 已标注，参与训练 |
| 预测集 | 2             | `prediction_filenames` | 待预测      |

***

## 快速开始

### 1. 构建项目

```bash
mkdir build
cd build
cmake ..
cmake --build . --config Release
```

### 2. 运行应用

```bash
./HIL.exe
```

### 3. 创建新项目

1. 点击 **"新建项目"**
2. 选择Python解释器路径（如 `C:/Python39/python.exe`）
3. 选择ITK-SNAP路径（如 `C:/ITK-SNAP/itksnap.exe`）
4. 输入项目名称
5. 生成配置文件
6. 完成数据集具体配置以及模型配置
7. 进入项目内，勾选训练集/预测集，开始训练/预测

***


### 数据集管理

1. 确保数据集目录结构符合要求
2. 在主窗口中点击 **"管理数据集"** 按钮
3. 在弹出的对话框中勾选要添加的数据集（默认添加目录下所有符合要求的数据集）
4. 点击刷新按钮重新扫描


### 训练流程

1. 在数据集列表中勾选要训练的数据集（需要有对应的label文件）
2. 点击 **"开始训练"** 按钮
3. 设置GPU数量和线程数
4. 等待训练完成

### 预测流程

1. 将数据集移动到预测集（右键菜单 → 移至预测集）
2. 点击 **"开始预测"** 按钮
3. 选择模型文件（默认使用最新训练模型）
4. 等待预测完成
5. 系统自动进行后处理转换

### 查看结果

- 双击数据集可打开ITK-SNAP查看
- 预测结果保存在 `{project_dir}/raw_output/predictions/`

***

## 项目结构

```
HIL/
├── form/                      # Qt UI表单文件
│   ├── mainwindow.ui
│   ├── projectManage.ui
│   ├── generateConfig.ui
│   └── ...
├── include/                   # 头文件
│   ├── mainwindow.h
│   ├── constants.h
│   └── ...
├── src/                       # 源代码
│   ├── main.cpp
│   ├── mainwindow.cpp
│   └── ...
├── scripts/                   # Python脚本
│   ├── checkEnv.py           # 环境检测
│   ├── generateConfig.py    # 配置生成
│   └── transRawOutput.py    # 预测输出转换
├── qrc/                       # 资源文件
├── CMakeLists.txt            # 构建配置
├── requirements.txt          # Python依赖
└── README.md
```

***

## 关于本项目
本项目基于QT6.9.1编译

本项目使用的训练/预测python文件来自项目：https://github.com/ellisdg/3DUnetCNN

所使用的文件位于**unet3d**下