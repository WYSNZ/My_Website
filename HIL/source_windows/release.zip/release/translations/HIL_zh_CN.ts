<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN" sourcelanguage="en_US">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../form/mainwindow.ui" line="14"/>
        <source>MainWindow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/mainwindow.ui" line="40"/>
        <location filename="../form/mainwindow.ui" line="119"/>
        <source>数据集</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../form/mainwindow.ui" line="52"/>
        <source>如果需要增添或删除数据集，请点击此按钮。在弹出的界面内勾选/取消勾选数据集</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../form/mainwindow.ui" line="55"/>
        <source>管理数据集</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../form/mainwindow.ui" line="62"/>
        <source>搜索数据集名称</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../form/mainwindow.ui" line="69"/>
        <source>清空搜索框</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../form/mainwindow.ui" line="72"/>
        <source>CLear</source>
        <translation>清空</translation>
    </message>
    <message>
        <location filename="../form/mainwindow.ui" line="124"/>
        <source>状态</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../form/mainwindow.ui" line="129"/>
        <source>训练集</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../form/mainwindow.ui" line="134"/>
        <location filename="../src/mainwindow.cpp" line="941"/>
        <source>预测集</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../form/mainwindow.ui" line="142"/>
        <source>自动勾选所有存在分割文件的数据集</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../form/mainwindow.ui" line="155"/>
        <source>勾选所有已标注数据集</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../form/mainwindow.ui" line="163"/>
        <location filename="../form/mainwindow.ui" line="285"/>
        <source>终端</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../form/mainwindow.ui" line="201"/>
        <source>你的python环境，配置文件路径以及ITK-snap路径</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../form/mainwindow.ui" line="210"/>
        <source>开始训练</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../form/mainwindow.ui" line="217"/>
        <source>开始预测</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../form/mainwindow.ui" line="224"/>
        <source>中止预测</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../form/mainwindow.ui" line="231"/>
        <source>中止训练</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../form/mainwindow.ui" line="249"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;meta charset=&quot;utf-8&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
hr { height: 1px; border-width: 0; }
li.unchecked::marker { content: &quot;\2610&quot;; }
li.checked::marker { content: &quot;\2612&quot;; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Consolas&apos;; font-size:16pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Microsoft YaHei UI&apos;;&quot;&gt;&lt;br /&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/mainwindow.ui" line="277"/>
        <source>配置</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/mainwindow.ui" line="292"/>
        <source>关于</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/mainwindow.ui" line="299"/>
        <source>返回</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/mainwindow.ui" line="310"/>
        <source>更改模型配置</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/mainwindow.ui" line="315"/>
        <source>选择环境</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/mainwindow.ui" line="320"/>
        <source>清空终端内容</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/mainwindow.ui" line="325"/>
        <source>字体</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/mainwindow.ui" line="336"/>
        <source>关于HIL...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/mainwindow.ui" line="341"/>
        <location filename="../form/mainwindow.ui" line="362"/>
        <source>debug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/mainwindow.ui" line="346"/>
        <source>选择新的配置文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/mainwindow.ui" line="351"/>
        <source>返回项目管理</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="96"/>
        <location filename="../src/mainwindow.cpp" line="899"/>
        <source>无法打开数据库</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="112"/>
        <source>BUILD_FAIL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="248"/>
        <source>LABEL_NOT_FOUND</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="253"/>
        <source>无法选择不存在label文件的数据集: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="432"/>
        <location filename="../src/mainwindow.cpp" line="466"/>
        <source>EXEC_FAIL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="475"/>
        <source>输入label文件名称</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="743"/>
        <source>正在将原始输出文件转换为分割图像</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="752"/>
        <source>预测完成</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="788"/>
        <source>原始输出文件夹不存在: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="791"/>
        <source>原始输出文件不存在</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="794"/>
        <source>原数据集不存在: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="797"/>
        <source>未知错误</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="800"/>
        <source>已转换：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="815"/>
        <source>(PYTHON_ENV_EMPTY)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="819"/>
        <source>(ITK_ENV_EMPTY)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="847"/>
        <source>label_name_NOT_FOUND</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="878"/>
        <source>选择字体</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="886"/>
        <source>人在回路(HIL)数据标注平台
该平台基于Qt 6.9.1与github开源项目(https://github.com/ellisdg/3DUnetCNN.git)开发</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="933"/>
        <source>未标记/空闲集</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="937"/>
        <source>已标记/训练集</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1003"/>
        <source>管理数据集内容是读取cache失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1007"/>
        <location filename="../src/mainwindow.cpp" line="1012"/>
        <location filename="../src/mainwindow.cpp" line="1023"/>
        <location filename="../src/mainwindow.cpp" line="1028"/>
        <source>配置文件出现错误，请检查模型配置</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1057"/>
        <source>移至预测集</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1058"/>
        <source>移至训练集</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1059"/>
        <source>移至空闲集</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1112"/>
        <source>移动模型失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1117"/>
        <source>清理模型失败</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../include/constants.h" line="8"/>
        <source>错误</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../include/constants.h" line="9"/>
        <source>警告</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../include/constants.h" line="10"/>
        <source>提示</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../include/constants.h" line="11"/>
        <source>完成</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../include/constants.h" line="13"/>
        <source>文件不存在:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../include/constants.h" line="14"/>
        <source>数据库操作失败:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../include/constants.h" line="15"/>
        <source>配置文件错误:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../include/constants.h" line="16"/>
        <source>进程已终止:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../include/constants.h" line="17"/>
        <source>输入验证失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../include/constants.h" line="19"/>
        <source>训练完成</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../include/constants.h" line="20"/>
        <source>预测完成</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../include/constants.h" line="21"/>
        <source>环境检测通过</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../include/constants.h" line="22"/>
        <source>环境检测未通过</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../include/constants.h" line="25"/>
        <source>请先选择数据集</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../include/constants.h" line="26"/>
        <source>请检查配置文件内容</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../include/constants.h" line="27"/>
        <source>请选择有效的文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../include/constants.h" line="28"/>
        <source>环境配置未完成</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../include/constants.h" line="32"/>
        <source>选择JSON文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../include/constants.h" line="33"/>
        <source>选择数据集文件夹</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../include/constants.h" line="34"/>
        <source>选择输出目录</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../include/constants.h" line="35"/>
        <source>选择Python解释器</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../include/constants.h" line="36"/>
        <source>选择ITK-SNAP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../include/constants.h" line="37"/>
        <source>选择模型文件</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>changeConfig</name>
    <message>
        <location filename="../form/changeConfig.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="35"/>
        <source>快速配置</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="41"/>
        <source>参与训练的分割文件的标签名称，仅填入数值(如0,1,2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="48"/>
        <source>训练总轮次，一般情况下，轮次越高，效果越好</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="61"/>
        <source>输出通道数</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="68"/>
        <source>单个数据集内CT图像数目(如40,70,vnc记作3个)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="81"/>
        <source>输入通道数</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="88"/>
        <source>训练轮次</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="95"/>
        <source>分割标签数目</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="108"/>
        <source>分割标签</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="118"/>
        <source>model</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="134"/>
        <source>depth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="142"/>
        <source>DynUnet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="147"/>
        <source>Unet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="162"/>
        <source>spatial_dims</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="169"/>
        <location filename="../form/changeConfig.ui" line="216"/>
        <location filename="../form/changeConfig.ui" line="253"/>
        <location filename="../form/changeConfig.ui" line="429"/>
        <location filename="../form/changeConfig.ui" line="558"/>
        <source>name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="186"/>
        <source>deep_supervision</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="196"/>
        <source>optimizer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="202"/>
        <source>learning_rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="209"/>
        <location filename="../form/changeConfig.ui" line="392"/>
        <source>1e-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="224"/>
        <source>AdamW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="229"/>
        <source>Adam</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="247"/>
        <source>loss</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="261"/>
        <source>DiceLoss</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="266"/>
        <source>FocalLoss</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="274"/>
        <source>include_background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="291"/>
        <source>activarion_function</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="299"/>
        <source>softmax</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="304"/>
        <source>sigmoid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="309"/>
        <source>Relu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="320"/>
        <source>cross validation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="326"/>
        <source>Enable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="333"/>
        <source>folds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="343"/>
        <source>seed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="356"/>
        <source>scheduler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="362"/>
        <source>min_learning_rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="370"/>
        <source>ReduceLROnPlateau</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="378"/>
        <source>patience</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="385"/>
        <source>factor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="412"/>
        <source>0.5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="439"/>
        <source>dataset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="446"/>
        <source>SegmentationDataset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="451"/>
        <source>SegmentationDatasetPersistent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="459"/>
        <source>nonzero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="486"/>
        <source>normalization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="503"/>
        <source>channel_wise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="517"/>
        <source>crop_foreground</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="524"/>
        <source>desired_shape</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="566"/>
        <source>NormalizeIntensityD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="574"/>
        <source>setup_label_hierarchy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="591"/>
        <source>resample</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="601"/>
        <source>traning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="607"/>
        <source>save_best</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="614"/>
        <source>amp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="631"/>
        <source>save_last_n_models</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="655"/>
        <source>batch_size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="662"/>
        <source>validation_batch_size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="669"/>
        <source>save_every_n_epochs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="693"/>
        <source>eraly_stopping_patience</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="707"/>
        <source>展示所有模型配置。注意：请不要随意改动下面任意一项的值，除非你真的知道你在干什么</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="710"/>
        <source>展示高级配置</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="717"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeConfig.ui" line="724"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/changeConfig.cpp" line="15"/>
        <source>改变当前配置</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>changeLang</name>
    <message>
        <location filename="../form/changeLang.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeLang.ui" line="20"/>
        <source>取消/Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeLang.ui" line="27"/>
        <source>确定/OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeLang.ui" line="34"/>
        <location filename="../form/changeLang.ui" line="60"/>
        <source>语言/Language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeLang.ui" line="41"/>
        <source>简体中文</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/changeLang.ui" line="46"/>
        <source>English</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>datasets</name>
    <message>
        <location filename="../src/generateConfig.cpp" line="386"/>
        <source>数据集</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/generateConfig.cpp" line="427"/>
        <source>已放入另一分类,无法选中</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>environmentControl</name>
    <message>
        <location filename="../form/environmentControl.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/environmentControl.ui" line="20"/>
        <source>环境管理</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/environmentControl.ui" line="26"/>
        <location filename="../form/environmentControl.ui" line="33"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/environmentControl.ui" line="46"/>
        <source>环境检验</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/environmentControl.ui" line="53"/>
        <source>选取ITK-SNAP路径</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/environmentControl.ui" line="63"/>
        <source>选取python环境</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/environmentControl.ui" line="70"/>
        <source>跳过</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/environmentControl.ui" line="77"/>
        <source>确定</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/environmentControl.cpp" line="6"/>
        <source>环境选择</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>generateConfig</name>
    <message>
        <location filename="../form/generateConfig.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="35"/>
        <source>快速配置</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="41"/>
        <location filename="../form/generateConfig.ui" line="195"/>
        <location filename="../form/generateConfig.ui" line="202"/>
        <source>浏览</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="48"/>
        <source>如存在多个分割图像文件，请勾选此项，否则无法正常训练</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="58"/>
        <source>CT图像名称(无后缀)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="65"/>
        <source>分割标签</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="72"/>
        <source>是否生成合并分割文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="79"/>
        <source>训练总轮次，一般情况下，轮次越高，效果越好</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="92"/>
        <source>单个数据集内CT图像数目(如40,70,vnc记作3个)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="105"/>
        <source>分割图像名称(无后缀)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="112"/>
        <source>输出通道数</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="119"/>
        <source>如mask(如存在多个，按照逗号分隔)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="126"/>
        <source>输入通道数</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="133"/>
        <source>训练轮次</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="140"/>
        <source>参与训练的分割文件的标签名称，仅填入数值(如0,1,2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="147"/>
        <source>如40,70,vnc(逗号分割，中英文均可)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="154"/>
        <source>指向数据集根目录</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="161"/>
        <source>分割标签数目</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="174"/>
        <source>数据集路径</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="181"/>
        <source>每个通道独立输入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="212"/>
        <source>model</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="228"/>
        <source>depth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="236"/>
        <source>DynUnet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="241"/>
        <source>Unet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="256"/>
        <source>spatial_dims</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="263"/>
        <location filename="../form/generateConfig.ui" line="310"/>
        <location filename="../form/generateConfig.ui" line="347"/>
        <location filename="../form/generateConfig.ui" line="523"/>
        <location filename="../form/generateConfig.ui" line="652"/>
        <source>name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="280"/>
        <source>deep_supervision</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="290"/>
        <source>optimizer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="296"/>
        <source>learning_rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="303"/>
        <location filename="../form/generateConfig.ui" line="486"/>
        <source>1e-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="318"/>
        <source>AdamW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="323"/>
        <source>Adam</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="341"/>
        <source>loss</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="355"/>
        <source>DiceLoss</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="360"/>
        <source>FocalLoss</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="368"/>
        <source>include_background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="385"/>
        <source>activarion_function</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="393"/>
        <source>softmax</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="398"/>
        <source>sigmoid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="403"/>
        <source>Relu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="414"/>
        <source>cross validation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="420"/>
        <source>Enable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="427"/>
        <source>folds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="437"/>
        <source>seed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="450"/>
        <source>scheduler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="456"/>
        <source>min_learning_rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="464"/>
        <source>ReduceLROnPlateau</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="472"/>
        <source>patience</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="479"/>
        <source>factor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="506"/>
        <source>0.5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="533"/>
        <source>dataset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="540"/>
        <source>SegmentationDataset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="545"/>
        <source>SegmentationDatasetPersistent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="553"/>
        <source>nonzero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="580"/>
        <source>normalization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="597"/>
        <source>channel_wise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="611"/>
        <source>crop_foreground</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="618"/>
        <source>desired_shape</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="660"/>
        <source>NormalizeIntensityD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="668"/>
        <source>setup_label_hierarchy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="685"/>
        <source>resample</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="695"/>
        <source>traning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="701"/>
        <source>save_best</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="708"/>
        <source>amp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="725"/>
        <source>save_last_n_models</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="749"/>
        <source>batch_size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="756"/>
        <source>validation_batch_size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="763"/>
        <source>save_every_n_epochs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="787"/>
        <source>eraly_stopping_patience</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="804"/>
        <source>选择项目文件夹</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="811"/>
        <source>展示所有模型配置。注意：请不要随意改动下面任意一项的值，除非你真的知道你在干什么</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="814"/>
        <source>展示高级配置</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="821"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/generateConfig.ui" line="828"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/generateConfig.cpp" line="219"/>
        <source>请输入数据集路径</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/generateConfig.cpp" line="223"/>
        <source>请输入CT图像名</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/generateConfig.cpp" line="227"/>
        <source>请输入CT图像名分割图像名</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/generateConfig.cpp" line="231"/>
        <source>请输入分割标签</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/generateConfig.cpp" line="356"/>
        <location filename="../src/generateConfig.cpp" line="371"/>
        <source>请先选择数据集路径</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/generateConfig.cpp" line="360"/>
        <source>选择CT文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/generateConfig.cpp" line="375"/>
        <source>选择分割文件</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>itemDoubleClick</name>
    <message>
        <location filename="../form/itemDoubleClick.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/itemDoubleClick.ui" line="32"/>
        <source>刷新</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/itemDoubleClick.ui" line="39"/>
        <source>打开文件时一同加载分割图像</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/itemDoubleClick.ui" line="46"/>
        <source>数据集预览</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/itemDoubleClick.ui" line="53"/>
        <source>dataset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/itemDoubleClick.cpp" line="69"/>
        <location filename="../src/itemDoubleClick.cpp" line="78"/>
        <source>无法打开文件: </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>manageDatasets</name>
    <message>
        <location filename="../form/manageDatasets.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/manageDatasets.ui" line="32"/>
        <source>刷新</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/manageDatasets.ui" line="51"/>
        <source>确定</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/manageDatasets.ui" line="58"/>
        <source>添加数据集</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/manageDatasets.ui" line="65"/>
        <source>datasets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/manageDatasets.cpp" line="16"/>
        <source>管理数据集</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/manageDatasets.cpp" line="390"/>
        <source>数据库内容异常</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>newProject</name>
    <message>
        <location filename="../form/newProject.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/newProject.ui" line="20"/>
        <source>确定</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/newProject.ui" line="27"/>
        <source>取消</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/newProject.ui" line="34"/>
        <location filename="../src/newProject.cpp" line="11"/>
        <source>新建项目</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/newProject.ui" line="40"/>
        <source>配置文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/newProject.ui" line="47"/>
        <source>项目名称</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/newProject.ui" line="54"/>
        <source>选择已有</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/newProject.ui" line="67"/>
        <source>新建</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>projectManage</name>
    <message>
        <location filename="../form/projectManage.ui" line="14"/>
        <source>HIL-项目管理</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/projectManage.ui" line="37"/>
        <source>人在回路</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/projectManage.ui" line="48"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;meta charset=&quot;utf-8&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
hr { height: 1px; border-width: 0; }
li.unchecked::marker { content: &quot;\2610&quot;; }
li.checked::marker { content: &quot;\2612&quot;; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Microsoft YaHei UI&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;center&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;HIL&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Human In the Loop&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;This is a 3DUnet based CNN model training platform&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/projectManage.ui" line="69"/>
        <location filename="../form/projectManage.ui" line="140"/>
        <source>项目</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/projectManage.ui" line="97"/>
        <source>项目名称</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/projectManage.ui" line="102"/>
        <source>创建时间</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/projectManage.ui" line="124"/>
        <source>新建</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/projectManage.ui" line="130"/>
        <source>语言/Language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/projectManage.ui" line="145"/>
        <source>更改语言/Change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/projectManage.cpp" line="13"/>
        <source>HIL--项目管理</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/projectManage.cpp" line="27"/>
        <location filename="../src/projectManage.cpp" line="149"/>
        <source>无法打开数据库</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/projectManage.cpp" line="41"/>
        <source>BUILD_FAIL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/projectManage.cpp" line="123"/>
        <source>:EXEC_ERROR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/projectManage.cpp" line="158"/>
        <source>打开</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/projectManage.cpp" line="159"/>
        <source>删除</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/projectManage.cpp" line="170"/>
        <source>确认删除?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/projectManage.cpp" line="170"/>
        <source>确认删除该项目?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/projectManage.cpp" line="229"/>
        <source>错误</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/projectManage.cpp" line="229"/>
        <source>无法加载翻译文件</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>startPrediction</name>
    <message>
        <location filename="../form/startPrediction.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/startPrediction.ui" line="20"/>
        <source>确定</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/startPrediction.ui" line="27"/>
        <source>返回</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/startPrediction.ui" line="34"/>
        <source>GroupBox</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/startPrediction.ui" line="46"/>
        <source>模型(.pth)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/startPrediction.ui" line="59"/>
        <source>输出文件路径</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/startPrediction.ui" line="72"/>
        <source>线程数</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/startPrediction.ui" line="85"/>
        <source>显卡数量</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/startPrediction.ui" line="125"/>
        <location filename="../form/startPrediction.ui" line="132"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/startPrediction.cpp" line="8"/>
        <source>预测参数</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/startPrediction.cpp" line="64"/>
        <source>文件夹创建失败: </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>startTraining</name>
    <message>
        <location filename="../form/startTraining.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/startTraining.ui" line="20"/>
        <source>训练配置</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/startTraining.ui" line="32"/>
        <source>使用的显卡数量</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/startTraining.ui" line="39"/>
        <source>返回</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/startTraining.ui" line="52"/>
        <source>模型保存路径</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/startTraining.ui" line="59"/>
        <source>确定</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/startTraining.ui" line="72"/>
        <source>线程数</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../form/startTraining.ui" line="109"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/startTraining.cpp" line="6"/>
        <source>训练参数</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/startTraining.cpp" line="44"/>
        <location filename="../src/startTraining.cpp" line="54"/>
        <source>文件夹创建失败: </source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
