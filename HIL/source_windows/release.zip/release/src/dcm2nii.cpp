#include "dcm2nii.h"

dcm2nii::dcm2nii(QWidget* parent,QString python)
    : QDialog{ parent }, ui(new Ui::dcm2nii) {
    ui->setupUi(this);
    this->python = python;

    connect(ui->btn_browse_dcm_dir, &QPushButton::clicked, this, &dcm2nii::on_btn_browse_dcm_dir_clicked);
    connect(ui->btn_browse_output_dir, &QPushButton::clicked, this, &dcm2nii::on_btn_browse_output_dir_clicked);
    connect(ui->btn_ok, &QPushButton::clicked, this, &dcm2nii::on_btn_ok_clicked);
    connect(ui->btn_cancel, &QPushButton::clicked, this, &dcm2nii::on_btn_cancel_clicked);
}

dcm2nii::~dcm2nii() {
    delete ui;
}

void dcm2nii::on_btn_browse_dcm_dir_clicked() {
    QString dcm = QFileDialog::getExistingDirectory(this, tr("选取dcm数据集根目录"), ui->dcm_dir->text().isEmpty() ? QDir::homePath() : ui->dcm_dir->text());
    ui->dcm_dir->setText(dcm);
}

void dcm2nii::on_btn_browse_output_dir_clicked() {
    QString output = QFileDialog::getExistingDirectory(this, tr("选取输出目录"), ui->output_dir->text().isEmpty() ? QDir::homePath() : ui->output_dir->text());
    ui->output_dir->setText(output);
}

void dcm2nii::on_btn_ok_clicked() {
    QString dcm = ui->dcm_dir->text();
    if (dcm.isEmpty()) {
        QMessageBox::warning(this, messageConstants::WARNING_TITLE, tr("请输入dcm数据集根目录"));
        return;
    }
    QString output = ui->output_dir->text();
    if (output.isEmpty()) {
        QMessageBox::warning(this, messageConstants::WARNING_TITLE, tr("请输入输出目录"));
        return;
    }
    QString output_name = ui->output_name->text();
    if (output_name.isEmpty()) {
        QMessageBox::warning(this, messageConstants::WARNING_TITLE, tr("请输入输出文件名"));
        return;
    }
    QProcess* process = new QProcess(this);
    QStringList args;
    args << QCoreApplication::applicationDirPath() + "/scripts/dcm2nii.py";
    args << "--dataset_root_dir" << dcm;
    args << "--output_dir" << output;
    args << "--output_name" << output_name;
    connect(process, &QProcess::started, this, [=]() {
        ui->terminal->append(tr("开始转换"));
        ui->terminal->append(tr("dcm路径：") + dcm);
        ui->terminal->append(tr("输出路径：") + output);
        });
    connect(process, &QProcess::readyReadStandardOutput, this, [=]() {
        ui->terminal->append(process->readAllStandardOutput());
        });
    connect(process, &QProcess::readyReadStandardError, this, [=]() {
        ui->terminal->append(process->readAllStandardError());
        });
    connect(process, &QProcess::finished, this, [=]() {
        if (process->exitStatus() == QProcess::NormalExit && process->exitCode() == 0) {
            ui->terminal->append(tr("转换完成，前往管理数据集内进行数据集添加"));
            QTimer::singleShot(3000, this, &QDialog::close);
        }
        else {
            ui->terminal->append(tr("转换失败"));
        }
        process->deleteLater();
        });
    process->start(python, args);
}

void dcm2nii::on_btn_cancel_clicked(){
    this->close();
}