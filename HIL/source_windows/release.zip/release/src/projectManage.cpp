#include "projectManage.h"

projectManage::projectManage(QWidget* parent)
    : QMainWindow{ parent }, ui(new Ui::projectManage) {
    ui->setupUi(this);
    create_database();
    create_cache_folder();
    connect(ui->actionNewProject, &QAction::triggered, this, &projectManage::on_action_newProject_triggered);
    connect(ui->projectsTable, &QTableWidget::itemDoubleClicked, this, &projectManage::on_item_double_clicked);
    connect(ui->projectsTable, &QTableWidget::customContextMenuRequested, this, &projectManage::on_item_right_clicked);
    connect(ui->actionChangeLang, &QAction::triggered, this, &projectManage::on_change_lang_triggered);
    refresh_projects_table();
    this->setWindowTitle(tr("HIL--项目管理"));
    this->setWindowIcon(QIcon(":/images/Logo.png"));
}
projectManage::~projectManage() {
    delete ui;
}
void projectManage::closeEvent(QCloseEvent* event) {
    QMainWindow::closeEvent(event);
}

void projectManage::create_database() {
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName(QCoreApplication::applicationDirPath() + "/projects.db");
    if (!db.open()) {
        QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::DATABASE_ERROR + tr("无法打开数据库"));
        return;
    }
    QSqlQuery query;
    bool success = query.exec(R"(
        CREATE TABLE IF NOT EXISTS
        projects(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        project_name TEXT,
        cache TEXT UNIQUE,
        create_time TEXT
        )
        )");
    if (!success) {
        QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::DATABASE_ERROR + tr("BUILD_FAIL") + "\n" + query.lastError().text());
        return;
    }
}
void projectManage::create_cache_folder() {
    QString cache_dir = QCoreApplication::applicationDirPath() + "/cache";
    if (QDir(cache_dir).exists()) return;
    QDir dir;
    if (!dir.mkpath(cache_dir)) {
        QMessageBox::warning(this, messageConstants::ERROR_TITLE, "缓存文件夹创建失败");
    }
}
void projectManage::on_action_newProject_triggered() {
    environmentControl* env = new environmentControl(this);
    if (env->exec() == QDialog::Accepted) {
        QString python_dir = env->python_env;
        QString itk_dir = env->itk_snap_path;
        dump_cache(python_dir, itk_dir);
        QString project_cache = QCoreApplication::applicationDirPath() + "/cache/" + QString::number(QDateTime::currentSecsSinceEpoch()) + ".ini";

        newProject* p = new newProject(this, python_dir, project_cache);
        if (p->exec() == QDialog::Accepted) {
            QSettings cache(project_cache, QSettings::IniFormat, this);
            cache.setValue("config_dir", p->config);
            cache.setValue("project_name", p->projectName);
            cache.setValue("label_name", p->label_name);
            cache.setValue("Environment/python", python_dir);
            cache.setValue("Environment/itk_snap", itk_dir);

            //clear_database_connnection();
            QSqlQuery query;
            query.prepare("INSERT INTO projects (project_name,cache,create_time) VALUES (?,?,?)");
            query.addBindValue(p->projectName);
            query.addBindValue(project_cache);
            query.addBindValue(QDateTime::currentDateTime().toString("yy-MM-dd hh:mm:ss"));
            if (!query.exec()) {
                QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::DATABASE_ERROR + query.lastError().text());
                return;
            }
            refresh_projects_table();

        }
    }
}

void projectManage::dump_cache(QString python, QString itk) {
    QSettings cache(QCoreApplication::applicationDirPath() + "/cache.ini", QSettings::IniFormat, this);
    cache.setValue("Environment/python", python);
    cache.setValue("Environment/itk_snap", itk);
    cache.sync();
}

void projectManage::refresh_projects_table() {
    ui->projectsTable->setRowCount(0);
    QSqlQuery query;
    if (!query.exec("SELECT id,project_name,create_time FROM projects")) {
        QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::DATABASE_ERROR + query.lastError().text());
        return;
    }
    while (query.next()) {
        int id = query.value(0).toInt();
        QString name = query.value(1).toString();
        QString time = query.value(2).toString();

        int row = ui->projectsTable->rowCount();
        ui->projectsTable->insertRow(row);
        QTableWidgetItem* item_name = new QTableWidgetItem(name);
        item_name->setData(Qt::UserRole, id);
        QTableWidgetItem* item_time = new QTableWidgetItem(time);
        ui->projectsTable->setItem(row, 0, item_name);
        ui->projectsTable->setItem(row, 1, item_time);
    }
}

void projectManage::on_item_double_clicked(QTableWidgetItem* item) {
    //clear_database_connnection();
    int row = item->row();
    int id = ui->projectsTable->item(row, 0)->data(Qt::UserRole).toInt();
    QSqlQuery query;
    query.prepare("SELECT project_name,cache FROM projects WHERE id=?");
    query.addBindValue(id);
    if (!query.exec()) {
        QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::DATABASE_ERROR + tr(":EXEC_ERROR"));
        return;
    }
    if (query.next()) {
        QString name = query.value(0).toString();
        QString cache = query.value(1).toString();

        QSqlDatabase old_db = QSqlDatabase::database();
        if (old_db.isOpen()) {
            old_db.close();
        }
        QSqlDatabase::removeDatabase(QSqlDatabase::defaultConnection);

        emit projectSelected(name, cache);
    }
}

void projectManage::clear_database_connnection() {
    QSqlDatabase old_db = QSqlDatabase::database();
    if (old_db.isOpen()) {
        old_db.close();
    }
    QSqlDatabase::removeDatabase(QSqlDatabase::defaultConnection);
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName(QCoreApplication::applicationDirPath() + "/projects.db");
    if (!db.open()) {
        QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::DATABASE_ERROR + tr("无法打开数据库"));
        return;
    }
}

void projectManage::on_item_right_clicked(const QPoint& pos) {
    QTableWidgetItem* item = ui->projectsTable->itemAt(pos);

    QMenu menu;
    QAction* action_open = menu.addAction(tr("打开"));
    QAction* action_delete = menu.addAction(tr("删除"));
    QAction* selected = menu.exec(ui->projectsTable->viewport()->mapToGlobal(pos));
    if (selected == action_open) {
        on_item_double_clicked(item);
    }
    else if (selected == action_delete) {
        delete_project(item);
    }
}

void projectManage::delete_project(QTableWidgetItem* item) {
    QMessageBox delete_dialog(QMessageBox::Warning, tr("确认删除?"), tr("确认删除该项目?"), QMessageBox::Ok | QMessageBox::Cancel, this);
    QCheckBox* delete_json_and_db = new QCheckBox("一同删除该项目的所有配置文件");
    delete_json_and_db->setCheckState(Qt::Checked);
    delete_dialog.setCheckBox(delete_json_and_db);
    int ret = delete_dialog.exec();
    if (ret == QMessageBox::Ok) {
        QSqlQuery query;
        query.prepare("SELECT cache FROM projects WHERE id=?");
        int id = ui->projectsTable->item(item->row(), 0)->data(Qt::UserRole).toInt();
        query.addBindValue(id);
        if (!query.exec()) {
            QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::DATABASE_ERROR + ":" + query.lastError().text());
            return;
        }
        QString cache_dir;
        if (query.next()) {
            cache_dir = query.value(0).toString();
        }


        QSettings ini(cache_dir, QSettings::IniFormat, this);
        QString config_dir = ini.value("config_dir").toString();
        ini.deleteLater();


        if (!QFile::remove(cache_dir)) {
            QMessageBox::warning(this, messageConstants::ERROR_TITLE, "DELETE_ERROR");
            return;
        }
        query.prepare("DELETE FROM projects WHERE id=?");
        query.addBindValue(id);
        if (!query.exec()) {
            QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::DATABASE_ERROR + ":" + query.lastError().text());
            return;
        }
        if (delete_json_and_db->isChecked()) {
            QString db_dir = QFileInfo(config_dir).absolutePath() + "/" + QFileInfo(config_dir).baseName() + ".db";
            if (QFileInfo(config_dir).exists()) {
                if (!QFile::remove(config_dir)) {
                    QMessageBox::warning(this, messageConstants::ERROR_TITLE, "DELETE_ERROR");
                }
            }
            if (QFileInfo(db_dir).exists()) {
                if (!QFile::remove(db_dir)) {
                    QMessageBox::warning(this, messageConstants::ERROR_TITLE, "DELETE_ERROR");
                }
            }
        }
        refresh_projects_table();
    }
}

void projectManage::on_change_lang_triggered() {
    changeLang* lang = new changeLang(this);
    connect(lang, &changeLang::lang_change, this, [=](QString lang_path) {
        if (load_lang(lang_path)) {
            ui->retranslateUi(this);
        }
        else {
            QMessageBox::warning(this, tr("错误"), tr("无法加载翻译文件"));
        }
        });
    lang->exec();
}

bool projectManage::load_lang(QString path) {
    static QTranslator* translator = nullptr;
    if (translator) {
        qApp->removeTranslator(translator);
        delete translator;
    }
    translator = new QTranslator();
    if (translator->load(path)) {
        qApp->installTranslator(translator);
        QSettings cache(QCoreApplication::applicationDirPath() + "/cache.ini", QSettings::IniFormat);
        cache.setValue("Lang", path);
        cache.sync();
        return true;
    }
    else {
        delete translator;
        translator = nullptr;
        return false;
    }
}
