#include <QApplication>
#include "mainwindow.h"
#include "projectManage.h"
#include <QEventLoop>
#include <QObject>
#include <QStyleHints>

void theme_change(bool is_dark_mode);

int main(int argc, char* argv[]) {
    QApplication a(argc, argv);
//主题管理：暗黑/浅色
    bool is_dark_mode = qApp->styleHints()->colorScheme() == Qt::ColorScheme::Dark;
    theme_change(is_dark_mode);
    QObject::connect(qApp->styleHints(), &QStyleHints::colorSchemeChanged, [=]() {
        bool theme = qApp->styleHints()->colorScheme() == Qt::ColorScheme::Dark;
        theme_change(theme);
        QStyle* style = qApp->style();
        style->unpolish(qApp);
        style->polish(qApp);
        });
//语言管理
    QSettings cache(QCoreApplication::applicationDirPath() + "/cache.ini",QSettings::IniFormat);
    QString lang = cache.value("Lang").toString();
    if (lang.isEmpty()) {
        projectManage::load_lang(":/translations/HIL_zh_CN.qm");
    }
    else {
        projectManage::load_lang(lang);
    }

    projectManage p;

    QObject::connect(&p, &projectManage::projectSelected, [&](QString name, QString cache_dir) {
        MainWindow* w = new MainWindow(nullptr, name, cache_dir);
        //w->init_database();
        w->load_cache();
        //w->setAttribute(Qt::WA_DeleteOnClose);

        QObject::connect(w, &MainWindow::back_project_manage, [&p, w]() {
            p.show();
            w->close();
            //w->deleteLater();
            });

        p.close();
        w->show();
        });

    p.show();

    return a.exec();
}

void theme_change(bool is_dark_mode) {
    QString qss = is_dark_mode ? ":/style-dark.qss" : ":/style-light.qss";
    QFile file(qss);
    if (file.open(QIODevice::ReadOnly)) {
        qApp->setStyleSheet(QLatin1String(file.readAll()));
    }
}
