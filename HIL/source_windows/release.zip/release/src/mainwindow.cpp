#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent, QString project_name, QString cache_dir)
    : QMainWindow(parent), ui(new Ui::MainWindow), config(nullptr), process_tr(nullptr), process_pre(nullptr), python_exe(""),
      itk_dir(""), project_name(project_name), cache_dir(cache_dir)
{
    ui->setupUi(this);
    ui->dataset->setSelectionMode(QTreeWidget::MultiSelection);
    ui->progressBar->setValue(0);

    env_info.insert("config_dir", "");
    env_info.insert("python_dir", "");
    env_info.insert("ITK-SNAP_dir", "");

    this->setWindowIcon(QIcon(":/images/Logo.png"));
    this->setWindowTitle("HIL--" + this->project_name);
    connect_signals();

    ui->btn_stop_pre->setEnabled(false);
    ui->btn_stop_training->setEnabled(false);
    ui->dataset->setColumnWidth(0, 90);
    ui->dataset->setColumnWidth(1, 90);
    ui->dataset->setColumnWidth(2, 50);
    ui->dataset->setColumnWidth(3, 50);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::connect_signals()
{
    connect(ui->action_changeConfig, &QAction::triggered, this, &MainWindow::on_action_changeConfig_triggered);
    connect(ui->dataset, &QTreeWidget::itemChanged, this, &MainWindow::on_annotated_changed);
    // connect(ui->action_loadFromFIles, &QAction::triggered, this, &MainWindow::on_load_from_files_triggered);
    connect(ui->dataset, &QTreeWidget::itemDoubleClicked, this, &MainWindow::on_item_double_clicked);
    //   connect(ui->set_selected_as_pre, &QPushButton::clicked, this, &MainWindow::on_set_selected_as_pre_clicked);
    connect(ui->btn_start_training, &QPushButton::clicked, this, &MainWindow::on_btn_strt_training_clicked);
    connect(ui->btn_stop_training, &QPushButton::clicked, this, &MainWindow::on_btn_stop_training_clicked);
    connect(ui->btn_start_pre, &QPushButton::clicked, this, &MainWindow::on_btn_start_pre_clicked);
    connect(ui->btn_stop_pre, &QPushButton::clicked, this, &MainWindow::on_btn_stop_pre_clicked);
    connect(ui->action_pythonEnv, &QAction::triggered, this, &MainWindow::get_py_env);
    connect(ui->actionClear, &QAction::triggered, this, &MainWindow::on_action_clear_terminal_triggered);
    connect(ui->actionFont, &QAction::triggered, this, &MainWindow::on_action_font_triggered);
    connect(ui->actionAboutHIL, &QAction::triggered, this, &MainWindow::on_action_about_triggered);
    connect(ui->action_back_pro_manage, &QAction::triggered, this, &MainWindow::on_back_project_manage_clicked);
    connect(ui->btn_check_annotated_datasets, &QPushButton::clicked, this, &MainWindow::on_btn_check_annotated_clicked);
    connect(ui->debug, &QAction::triggered, this, &MainWindow::debug);
    connect(ui->btn_manage_dataset, &QPushButton::clicked, this, &MainWindow::on_btn_manage_dataset_clicked);
    connect(ui->dataset, &QTreeWidget::customContextMenuRequested, this, &MainWindow::on_dataset_right_clicked);
    connect(ui->serach, &QLineEdit::textChanged, this, &MainWindow::filter_datasets);
    connect(ui->btn_clear_search, &QPushButton::clicked, this, &MainWindow::clear_search_result);
    connect(ui->actionDcm_to_nii, &QAction::triggered, this, &MainWindow::on_action_dcm_2_nii_triggered);
    connect(ui->actionExportIPP, &QAction::triggered, this, &MainWindow::on_action_export_ipp_triggered);
}
void MainWindow::debug()
{
    QString test = QInputDialog::getText(this, "debug", "debug", QLineEdit::Normal, "");
    ui->terminal->append(test);
}
void MainWindow::on_action_changeConfig_triggered()
{
    config = new changeConfig(this, config_dir, cache_dir);

    config->exec();
    config->deleteLater();
}

void MainWindow::analyze_json_file()
{
    QFile file(config_dir);
    if (!file.open(QIODevice::ReadOnly))
    {
        QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::CONFIG_ERROR + config_dir);
        return;
    }
    init_database();
    QJsonDocument doc = QJsonDocument::fromJson(file.readAll());
    file.close();
    QJsonArray training = doc["training_filenames"].toArray();
    QJsonArray prediction = doc["prediction_filenames"].toArray();
    QJsonArray rest = doc["rest_filenames"].toArray();
    QJsonArray filenames;
    for (QJsonValue item : training)
    {
        filenames.append(item);
    }
    for (QJsonValue item : prediction)
    {
        filenames.append(item);
    }
    for (QJsonValue item : rest)
    {
        filenames.append(item);
    }
    insert_dataset(filenames);
    update_dataset_list();
}
/***
 * @todo 这里再反复初始化数据库但未指定连接名，可能出现问题，后续增加判断，连接名不对则断掉之后重连
 */
void MainWindow::init_database()
{
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName(QFileInfo(config_dir).absolutePath() + '/' + QFileInfo(config_dir).baseName() + ".db");
    if (!db.open())
    {
        QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::DATABASE_ERROR + tr("无法打开数据库"));
        return;
    }

    QSqlQuery query;
    bool success = query.exec(R"(
        CREATE TABLE IF NOT EXISTS
        files(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE,
        img_dir TEXT,
        label_dir TEXT,
        annotated INTEGER DEFAULT 0
        )
        )");
    if (!success)
    {
        QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::DATABASE_ERROR + tr("BUILD_FAIL"));
        return;
    }
    return;
}

void MainWindow::insert_dataset(QJsonArray &files)
{
    QSqlQuery query;
    query.exec("DELETE FROM files");
    query.exec("DELETE FROM sqlite_sequence WHERE name='files'");
    query.prepare("INSERT INTO files (name,img_dir) VALUES (?,?)");
    QHash<QString, dataset_item> map;
    for (const QJsonValue &item : files)
    {
        QJsonObject obj = item.toObject();
        QJsonArray images = obj["image"].toArray();

        QFileInfo info(images[0].toString());
        QString name = info.absolutePath().split("/").last();

        QString img_dirs;
        if (map.contains(name))
        {
            img_dirs = map.value(name).img_dir;
        }
        for (const QJsonValue &dir : images)
        {
            if (!img_dirs.isEmpty())
                img_dirs += ';';
            img_dirs += QFileInfo(dir.toString()).absoluteFilePath();
        }
        if (map.contains(name))
        {
            map[name].img_dir = img_dirs;
        }
        else
        {
            dataset_item dataset;
            dataset.name = name;
            dataset.img_dir = img_dirs;
            map.insert(name, dataset);
        }
    }
    for (auto it = map.begin(); it != map.end(); ++it)
    {
        query.addBindValue(it.key());
        query.addBindValue(it.value().img_dir);
        if (!query.exec())
        {
            QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::DATABASE_ERROR + ":EXEC_FAIL");
            continue;
        }
    }
    return;
}

std::optional<dataset_item> MainWindow::query_dataset(QString name)
{
    QSqlQuery query;
    query.prepare("SELECT id,img_dir,label_dir,annotated FROM files WHERE name=?");
    query.addBindValue(name);
    if (!query.exec())
    {
        QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::DATABASE_ERROR + query.lastError().text());
        return std::nullopt;
    }
    if (query.next())
    {
        dataset_item item;
        item.id = query.value(0).toInt();
        item.img_dir = query.value(1).toString();
        item.label_dir = query.value(2).toString();
        item.annotated = query.value(3).toInt();
        item.name = name;
        return item;
    }
    return std::nullopt;
}

void MainWindow::update_annotated(int id, int annotated)
{
    QSqlQuery query;
    query.prepare("UPDATE files SET annotated=? WHERE id=?");
    query.addBindValue(annotated);
    query.addBindValue(id);
    if (!query.exec())
    {
        QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::DATABASE_ERROR + query.lastError().text());
        return;
    }
    return;
}

void MainWindow::update_dataset_list()
{
    init_database();
    ui->dataset->clear();
    QSqlQuery query;
    if (!query.exec("SELECT id, name, annotated FROM files"))
    {
        QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::DATABASE_ERROR + query.lastError().text());
        return;
    }
    while (query.next())
    {
        int id = query.value(0).toInt();
        QString name = query.value(1).toString();
        int annotated = query.value(2).toInt();

        QTreeWidgetItem *item = new QTreeWidgetItem(ui->dataset);

        item->setText(0, name);
        item->setData(0, Qt::UserRole, id);
        // item->setData(3, Qt::UserRole + 1, id);
        ui->dataset->blockSignals(true);
        if (annotated == 0)
        {
            item->setCheckState(2, Qt::Unchecked);
            item->setCheckState(3, Qt::Unchecked);
        }
        else if (annotated == 1)
        {
            item->setCheckState(2, Qt::Checked);
            item->setCheckState(3, Qt::Unchecked);
        }
        else if (annotated == 2)
        {
            item->setCheckState(3, Qt::Checked);
            item->setCheckState(2, Qt::Unchecked);
        }
        ui->dataset->blockSignals(false);
        update_dataset_status(item, annotated);
        // item->setBackground(0, annotated ? this->annotated : this->not_annotated);
    }
}

void MainWindow::on_annotated_changed(QTreeWidgetItem *item, int column)
{
    if (column != 2 && column != 3)
        return;
    ui->dataset->blockSignals(true);

    QString name = item->text(0);
    bool checked_training = (item->checkState(2) == Qt::Checked);
    bool checked_prediction = (item->checkState(3) == Qt::Checked);

    auto data = query_dataset(name);
    if (!data.has_value())
    {
        ui->dataset->blockSignals(false);
        return;
    }

    dataset_item ds = data.value();
    if (checked_training && ds.annotated != 1)
    {
        QString label_path = ds.img_dir.split(';').first();
        if (label_path.isEmpty())
        {
            QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::DATABASE_ERROR + tr("LABEL_NOT_FOUND"));
            ui->dataset->blockSignals(false);
            return;
        }
        QString expected_label = QFileInfo(label_path).absolutePath() + '/' + label_name + ".nii.gz";
        if (!QFile::exists(expected_label))
        {
            ui->terminal->append(tr("无法选择不存在label文件的数据集: ") + expected_label);
            item->setCheckState(2, Qt::Unchecked);
            ui->dataset->blockSignals(false);
            return;
        }
        // item->setFlags(item->flags() & ~Qt::ItemIsSelectable);
        if (checked_prediction)
        {
            item->setCheckState(3, Qt::Unchecked);
            json_a_to_b("prediction_filenames", "training_filenames", name, expected_label);
        }
        else
        {
            json_a_to_b("rest_filenames", "training_filenames", name, expected_label);
        }
        update_annotated(ds.id, 1);
        update_dataset_status(item, 1);
    }
    else if (checked_prediction && ds.annotated != 2)
    {
        // item->setFlags(item->flags() | Qt::ItemIsSelectable);
        if (checked_training)
        {
            item->setCheckState(2, Qt::Unchecked);
            json_a_to_b("training_filenames", "prediction_filenames", name);
        }
        else
        {
            json_a_to_b("rest_filenames", "prediction_filenames", name);
        }
        update_annotated(ds.id, 2);
        update_dataset_status(item, 2);
    }
    else
    {
        // item->setFlags(item->flags() | Qt::ItemIsSelectable);
        json_a_to_b("training_filenames", "rest_filenames", name);
        json_a_to_b("prediction_filenames", "rest_filenames", name);
        update_annotated(ds.id, 0);
        update_dataset_status(item, 0);
    }
    ui->dataset->blockSignals(false);
    // if (checked) {
    //     QString labelPath = ds.img_dir.split(';').first();
    //     if (labelPath.isEmpty()) {
    //         QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::DATABASE_ERROR + tr("LABEL_NOT_FOUND"));
    //         return;
    //     }
    //     QFileInfo imgInfo(labelPath);
    //     QString expectedLabel = imgInfo.absolutePath() + '/' + label_name + ".nii.gz";

    //     if (!QFile::exists(expectedLabel)) {
    //         QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::FILE_NOT_FOUND + expectedLabel);
    //         item->setCheckState(0, Qt::Unchecked);
    //         ui->dataset->blockSignals(false);
    //         return;
    //     }
    //     item->setFlags(item->flags() & ~Qt::ItemIsSelectable);
    //     move_to_training(name, expectedLabel);
    //     update_annotated(ds.id, true);
    //     update_dataset_status(item, 1);
    // }
    // else {
    //     item->setFlags(item->flags() | Qt::ItemIsSelectable);
    //     move_to_rest(name);
    //     update_annotated(ds.id, false);
    //     update_dataset_status(item, 0);
    // }
}

// void MainWindow::move_to_training(const QString& name, const QString& labelPath) {
//     QFile file(config_dir);
//     if (!file.open(QIODevice::ReadWrite)) return;
//     QJsonDocument doc = QJsonDocument::fromJson(file.readAll());
//     QJsonObject root = doc.object();
//     QJsonArray training = root["training_filenames"].toArray();
//     QJsonArray prediction = root["prediction_filenames"].toArray();
//     QJsonArray rest = root["rest_filenames"].toArray();
//     for (int i = 0; i < rest.size(); ++i) {
//         QJsonObject obj = rest[i].toObject();
//         QJsonArray images = obj["image"].toArray();
//         if (images.isEmpty()) continue;
//         QFileInfo info(images[0].toString());
//         if (info.absolutePath().split("/").last() == name) {
//             obj["label"] = labelPath;
//             training.append(obj);
//             rest.removeAt(i);
//             break;
//         }
//     }
//     for (int i = 0; i < prediction.size(); ++i) {
//         QJsonObject obj = prediction[i].toObject();
//         QJsonArray images = obj["image"].toArray();
//         if (images.isEmpty()) continue;
//         QFileInfo info(images[0].toString());
//         if (info.absolutePath().split("/").last() == name) {
//             obj["label"] = labelPath;
//             training.append(obj);
//             prediction.removeAt(i);
//             break;
//         }
//     }
//     root["training_filenames"] = training;
//     root["prediction_filenames"] = prediction;
//     root["rest_filenames"] = rest;
//     doc.setObject(root);
//     file.resize(0);
//     file.write(doc.toJson());
//     file.close();
//     QSqlQuery query;
//     query.prepare("UPDATE files SET label_dir = ? WHERE name = ?");
//     query.addBindValue(labelPath);
//     query.addBindValue(name);
//     if (!query.exec()) {
//         QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::DATABASE_ERROR + tr("QUERY_FAIL"));
//     }
// }

// void MainWindow::move_to_rest(const QString& name) {
//     QFile file(config_dir);
//     if (!file.open(QIODevice::ReadWrite)) return;
//     QJsonDocument doc = QJsonDocument::fromJson(file.readAll());
//     QJsonObject root = doc.object();
//     QJsonArray training = root["training_filenames"].toArray();
//     QJsonArray rest = root["rest_filenames"].toArray();
//     for (int i = 0; i < training.size(); ++i) {
//         QJsonObject obj = training[i].toObject();
//         QJsonArray images = obj["image"].toArray();
//         if (images.isEmpty()) continue;
//         QFileInfo info(images[0].toString());
//         if (info.absolutePath().split("/").last() == name) {
//             obj.remove("label");
//             rest.append(obj);
//             training.removeAt(i);
//             break;
//         }
//     }
//     root["training_filenames"] = training;
//     root["rest_filenames"] = rest;
//     doc.setObject(root);
//     file.resize(0);
//     file.write(doc.toJson());
//     file.close();
//     QSqlQuery query;
//     query.prepare("UPDATE files SET label_dir = '' WHERE name = ?");
//     query.addBindValue(name);
//     if (!query.exec()) {
//         QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::DATABASE_ERROR + tr("QUERY_ERROR"));
//     }
// }

void MainWindow::json_a_to_b(const QString &label_a, const QString &label_b, const QString &name)
{
    QFile file(config_dir);
    if (!file.open(QIODevice::ReadWrite))
    {
        return;
    }
    QJsonDocument doc = QJsonDocument::fromJson(file.readAll());
    QJsonObject root = doc.object();
    QJsonArray _a = root[label_a].toArray();
    QJsonArray _b = root[label_b].toArray();
    for (int i = 0; i < _a.size(); ++i)
    {
        QJsonObject obj = _a[i].toObject();
        QJsonArray image = obj["image"].toArray();
        if (image.isEmpty())
            continue;
        QFileInfo info(image[0].toString());
        if (info.absolutePath().split('/').last() == name)
        {
            if (obj.contains("label"))
                obj.remove("label");
            _b.append(obj);
            _a.removeAt(i);
            i--; // 由于动态移动，将当前位置的dataset移走后，需要保持i不变
        }
    }
    root[label_a] = _a;
    root[label_b] = _b;
    doc.setObject(root);
    file.resize(0);
    file.write(doc.toJson());
    file.close();

    QSqlQuery query;
    query.prepare("UPDATE files SET label_dir='' WHERE name=?");
    query.addBindValue(name);
    if (!query.exec())
    {
        QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::DATABASE_ERROR + tr("EXEC_FAIL"));
    }
}
void MainWindow::json_a_to_b(const QString &label_a, const QString &label_b, const QString &name, const QString &label_path)
{
    QFile file(config_dir);
    if (!file.open(QIODevice::ReadWrite))
        return;
    QJsonDocument doc = QJsonDocument::fromJson(file.readAll());
    QJsonObject root = doc.object();
    QJsonArray _a = root[label_a].toArray();
    QJsonArray _b = root[label_b].toArray();
    for (int i = 0; i < _a.size(); ++i)
    {
        QJsonObject obj = _a[i].toObject();
        QJsonArray image = obj["image"].toArray();
        if (image.isEmpty())
            continue;
        QFileInfo info(image[0].toString());
        if (info.absolutePath().split('/').last() == name)
        {
            obj["label"] = label_path;
            _b.append(obj);
            _a.removeAt(i);
            i--;
        }
    }
    root[label_a] = _a;
    root[label_b] = _b;
    doc.setObject(root);
    file.resize(0);
    file.write(doc.toJson());
    file.close();

    QSqlQuery query;
    query.prepare("UPDATE files SET label_dir=? WHERE name=?");
    query.addBindValue(label_path);
    query.addBindValue(name);
    if (!query.exec())
    {
        QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::DATABASE_ERROR + tr("EXEC_FAIL"));
    }
}

// void MainWindow::on_load_from_files_triggered() {
//     QString json_path = QFileDialog::getOpenFileName(this, DialogTitles::SELECT_JSON_FILE, "", "JSON Files(*.json);;All Files(*.*)");
//     if (!QFileInfo::exists(json_path)) return;

//     bool ok;
//     label_name = QInputDialog::getText(this, tr("输入label文件名称"), "Label_name", QLineEdit::Normal, "debug_place", &ok);
//     if (!ok) return;

//     config_dir = json_path;
//     update_env_info_browser("config_dir", config_dir);

//     update_dataset_list();
// }

void MainWindow::on_item_double_clicked(QTreeWidgetItem *item, int column)
{
    QString name = item->text(0);
    auto data = query_dataset(name);
    if (data.has_value())
    {
        dataset_item val = data.value();
        itemDoubleClick *item_dc = new itemDoubleClick(this, val.img_dir, val.label_dir, label_name, itk_dir);
        item_dc->exec();
        item_dc->deleteLater();
    }
    else
    {
        QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::DATABASE_ERROR);
        return;
    }
}

// void MainWindow::on_set_selected_as_pre_clicked() {
//     QList<QTreeWidgetItem*> items = ui->dataset->selectedItems();
//     if (items.isEmpty()) {
//         QMessageBox::warning(this, messageConstants::INFO_TITLE, messageConstants::SELECT_DATASET_FIRST);
//         return;
//     }
//     QFile file(config_dir);
//     if (!file.open(QIODevice::ReadWrite)) {
//         QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::CONFIG_ERROR + tr("OPEN_FAIL"));
//         return;
//     }
//     QJsonDocument doc = QJsonDocument::fromJson(file.readAll());
//     QJsonObject root = doc.object();
//     QJsonArray rest = root["rest_filenames"].toArray();
//     QJsonArray prediction = root["prediction_filenames"].toArray();
//     for (QTreeWidgetItem* item : items) {
//         QString name = item->text(0);
//         for (int i = 0; i < rest.size(); ++i) {
//             QJsonObject obj = rest[i].toObject();
//             QJsonArray images = obj["image"].toArray();
//             if (images.isEmpty()) continue;
//             QFileInfo info(images[0].toString());
//             if (info.absolutePath().split("/").last() == name) {
//                 prediction.append(obj);
//                 rest.removeAt(i);
//                 update_dataset_status(item, 2);
//                 QSqlQuery query;
//                 query.prepare("UPDATE files SET annotated = ? WHERE id=?");
//                 query.addBindValue(2);
//                 query.addBindValue(item->data(0, Qt::UserRole).toInt());
//                 if (!query.exec()) {
//                     QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::DATABASE_ERROR + ":EXEC_FAIL");
//                 }
//                 break;
//             }
//         }
//     }
//     root["rest_filenames"] = rest;
//     root["prediction_filenames"] = prediction;
//     doc.setObject(root);
//     file.resize(0);
//     file.write(doc.toJson());
//     file.close();
//     for (QTreeWidgetItem* item : items) {
//         item->setSelected(false);
//     }
// }

void MainWindow::update_env_info_browser(QString key, QString val)
{
    env_info[key] = val;
    ui->config_info->clear();
    for (auto it = env_info.begin(); it != env_info.end(); it++)
    {
        if (it.key() == "config_dir")
        {
            ui->config_info->append("配置文件: " + it.value());
        }
        if (it.key() == "python_dir")
        {
            ui->config_info->append("python路径: " + it.value());
        }
        if (it.key() == "ITK-SNAP_dir")
        {
            ui->config_info->append("ITK-SNAP路径: " + it.value());
        }
    }
}

void MainWindow::init_msg()
{
    QStringList hello = {
        " _   _  ___  _ ",
        "| | | ||_ _|| |",
        "| |_| | | | | |",
        "|  _  | | | | |___",
        "|_| |_||___||_____|",
        "Welcome to HIL---Human In the Loop",
        "This is a 3dUnet based CNN model training platform"};
    // static int index = 0;

    if (index_msg < hello.size())
    {
        ui->terminal->append(hello[index_msg]);
        index_msg++;
        QTimer::singleShot(280, this, &MainWindow::init_msg);
    }
}

void MainWindow::on_btn_strt_training_clicked()
{
    startTraining *train = new startTraining(this, QFileInfo(config_dir).absolutePath());
    int ngpus = 0;
    int nthreads = 0;
    QString output_dir = "";
    if (train->exec() == QDialog::Accepted)
    {
        ngpus = train->ngpus;
        nthreads = train->nthreads;
        output_dir = train->output_dir;
        train->deleteLater();
    }
    else
    {
        train->deleteLater();
        return;
    }
    if (config_dir.isEmpty() || !QFileInfo(config_dir).exists())
    {
        QMessageBox::warning(this, messageConstants::WARNING_TITLE, messageConstants::CHECK_CONFIG_CONTENT);
        return;
    }
    if (process_tr)
    {
        process_tr->kill();
        process_tr->deleteLater();
        process_tr = nullptr;
    }
    process_tr = new QProcess(this);
    process_tr->setWorkingDirectory(QCoreApplication::applicationDirPath());
    QStringList args;
    args << "-u" << "-m" << "unet3d.scripts.train";
    args << "--output_dir" << output_dir;
    args << "--config_filename" << config_dir;
    args << "--ngpus" << QString::number(ngpus);
    args << "--nthreads" << QString::number(nthreads);
    process_tr->setProcessChannelMode(QProcess::MergedChannels);
    process_tr->setProperty("n_epochs", 0);

    connect(process_tr, &QProcess::readyReadStandardOutput, this, [this]()
            {
        QString output = process_tr->readAllStandardOutput();
        ui->terminal->append(output);
        int n_epochs = process_tr->property("n_epochs").toInt();
        capture_n_epoches(output, n_epochs);
        int batch_size = 0, cur = 0;
        capture_current_epoch(output, batch_size, cur);
        if (n_epochs != 0 && batch_size != 0)
            update_progress_bar(n_epochs * batch_size, cur);
        // ui->terminal->append(QString::number(n_epochs));
        // ui->terminal->append(QString::number(batch_size));
        // ui->terminal->append(QString::number(cur));
        process_tr->setProperty("n_epochs", n_epochs); });

    connect(process_tr, &QProcess::readyReadStandardError, this, [this]()
            { ui->terminal->append(process_tr->readAllStandardError()); });
    connect(process_tr, &QProcess::started, this, [=]()
            {
                ui->btn_start_training->setEnabled(false);
                ui->btn_stop_training->setEnabled(true);
                block_dataset_change();
                ui->progressBar->setRange(0, 100);
                ui->progressBar->setValue(0);
                // ui->progressBar->setRange(0, 0);
            });
    connect(process_tr, &QProcess::finished, this, [=]()
            {
        ui->progressBar->setRange(0, 100);
        recover_dataset_change();
        if (process_tr->exitStatus() != QProcess::NormalExit || process_tr->exitCode() != 0) {
            ui->progressBar->setValue(0);
            QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::PROCESS_TERMINATED);
        }
        else {
            copy_models();
            ui->progressBar->setValue(100);
            QMessageBox::information(this, messageConstants::SUCCESS_TITLE, messageConstants::TRAINING_COMPLETE);
        }
        ui->btn_start_training->setEnabled(true);
        ui->btn_stop_training->setEnabled(false); });
    process_tr->start(python_exe, args);
}

void MainWindow::on_btn_stop_training_clicked()
{
    if (!process_tr)
        return;
    process_tr->terminate();
    if (!process_tr->waitForFinished(3000))
    {
        process_tr->kill();
    }
    ui->btn_start_training->setEnabled(true);
    ui->btn_stop_training->setEnabled(false);
    recover_dataset_change();
    /// QMessageBox::information(this, messageConstants::INFO_TITLE, messageConstants::PROCESS_TERMINATED);
}

void MainWindow::on_btn_start_pre_clicked()
{
    startPrediction *pre = new startPrediction(this, QFileInfo(config_dir).absolutePath());
    QString output_dir = "";
    QString model_dir = "";
    int ngpus = 0;
    int nthreads = 0;
    if (pre->exec() == QDialog::Accepted)
    {
        output_dir = pre->output_dir;
        model_dir = pre->model_dir;
        ngpus = pre->ngpus;
        nthreads = pre->nthreads;
        pre->deleteLater();
    }
    else
    {
        pre->deleteLater();
        return;
    }
    if (config_dir.isEmpty() || !QFileInfo(config_dir).exists())
    {
        QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::CHECK_CONFIG_CONTENT);
        return;
    }
    if (process_pre)
    {
        process_pre->kill();
        process_pre->deleteLater();
        process_pre = nullptr;
    }
    process_pre = new QProcess(this);
    process_pre->setWorkingDirectory(QCoreApplication::applicationDirPath());
    QStringList args;
    args << "-u" << "-m";
    args << "unet3d.scripts.predict";
    args << "--config_filename" << config_dir;
    args << "--output_dir" << output_dir;
    args << "--model_filename" << model_dir;
    args << "--ngpus" << QString::number(ngpus);
    args << "--nthreads" << QString::number(nthreads);
    args << "--group" << "prediction";

    process_pre->setProcessChannelMode(QProcess::MergedChannels);
    process_pre->setProperty("total", 0);
    process_pre->setProperty("current", 0);
    connect(process_pre, &QProcess::started, this, [=]()
            {
        ui->btn_start_pre->setEnabled(false);
        ui->btn_stop_pre->setEnabled(true);
        ui->progressBar->setRange(0, 100);
        ui->progressBar->setValue(0);
        block_dataset_change(); });
    connect(process_pre, &QProcess::readyReadStandardOutput, this, [=]()
            {
                QString output = process_pre->readAllStandardOutput();
                ui->terminal->append(output);
                int total = process_pre->property("total").toInt();
                int current = process_pre->property("current").toInt();
                capture_prediction_progress(output, total, current);
                if (total != 0)
                {
                    update_progress_bar(total, current);
                }
                process_pre->setProperty("total", total);
                process_pre->setProperty("current", current);
            });
    connect(process_pre, &QProcess::readyReadStandardError, this, [=]()
            { ui->terminal->append(process_pre->readAllStandardError()); });
    connect(process_pre, &QProcess::finished, this, [=]()
            {
        ui->progressBar->setRange(0, 100);

        if (process_pre->exitStatus() != QProcess::NormalExit || process_pre->exitCode() != 0) {
            QMessageBox::warning(this, messageConstants::WARNING_TITLE, messageConstants::PROCESS_TERMINATED);
        }
        else {
            QDir dir(output_dir + "/predictions");
            //ui->terminal->append(output_dir + "/predictions");
            dir.setNameFilters(QStringList() << "*.nii.gz");
            QFileInfoList filelist = dir.entryInfoList(QDir::Files | QDir::NoDotAndDotDot);

            // QProgressDialog* waiting_for_finished = new QProgressDialog(tr("正在将原始输出转换为分割文件..."), "", 0, 0, this);
            // waiting_for_finished->setWindowTitle(tr("请稍等"));
            // waiting_for_finished->setWindowModality(Qt::WindowModal);
            // waiting_for_finished->setCancelButton(nullptr);
            // waiting_for_finished->setMinimumDuration(0);
            // waiting_for_finished->show();
            ui->terminal->append(tr("正在将原始输出文件转换为分割图像"));
            
            auto dataset = query_dataset(filelist[0].baseName());
            if (!dataset.has_value()) return;
            run_after_process_script(output_dir, QFileInfo(dataset.value().img_dir.split(';')[0]).absolutePath());
            

            // waiting_for_finished->close();

        }
        recover_dataset_change();
        ui->btn_start_pre->setEnabled(true);
        ui->btn_stop_pre->setEnabled(false); });
    process_pre->start(python_exe, args);
}

void MainWindow::on_btn_stop_pre_clicked()
{
    if (!process_pre)
        return;
    process_pre->terminate();
    if (!process_pre->waitForFinished(3000))
    {
        process_pre->kill();
    }
    ui->btn_start_pre->setEnabled(true);
    ui->btn_stop_pre->setEnabled(false);
    recover_dataset_change();
    // QMessageBox::information(this, messageConstants::INFO_TITLE, messageConstants::PROCESS_TERMINATED);
}

void MainWindow::run_after_process_script(QString pre_output_dir, QString original_dataset)
{
    QProcess *process_afp = new QProcess(this);
    QStringList args;
    args << QCoreApplication::applicationDirPath() + "/scripts/transRawOutput.py";
    args << "-u";
    args << "--output_dir" << pre_output_dir;
    args << "--dataset_root_dir" << QFileInfo(original_dataset).absolutePath();
    args << "--segmentation_name" << label_name;

    connect(process_afp, &QProcess::readyReadStandardError, this, [=]()
            { ui->terminal->append(process_afp->readAllStandardError()); });
    connect(process_afp, &QProcess::finished, this, [=]()
            {
        if (process_afp->exitCode() == 1) {
            QMessageBox::warning(this, messageConstants::ERROR_TITLE, tr("原始输出文件夹不存在: ") + pre_output_dir);
        }
        else if (process_afp->exitCode() == 2) {
            QMessageBox::warning(this, messageConstants::ERROR_TITLE, tr("原始输出文件不存在"));
        }
        else if (process_afp->exitCode() == 3) {
            QMessageBox::warning(this, messageConstants::ERROR_TITLE, tr("原数据集不存在: ") + original_dataset);
        }
        else if (process_afp->exitCode() != 0) {
            QMessageBox::warning(this, messageConstants::ERROR_TITLE, tr("未知错误"));
        }
        else {
            ui->progressBar->setValue(100);
            ui->terminal->append(tr("预测完成"));
            QMessageBox::information(this, messageConstants::SUCCESS_TITLE, messageConstants::PREDICTION_COMPLETE);
        }
        process_afp->deleteLater(); });
    connect(process_afp,&QProcess::readyReadStandardOutput,this,[=](){
        ui->terminal->append(process_afp->readAllStandardOutput());
    });
    process_afp->start(python_exe, args);
}

void MainWindow::get_py_env()
{
    environmentControl *env = new environmentControl(this);
    if (env->exec() == QDialog::Rejected)
    {
        env->deleteLater();
        return;
    }
    python_exe = env->python_env;
    if (python_exe.isEmpty())
    {
        QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::SELECT_VALID_FILE + tr("(PYTHON_ENV_EMPTY)"));
    }
    itk_dir = env->itk_snap_path;
    if (itk_dir.isEmpty())
    {
        QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::SELECT_VALID_FILE + tr("(ITK_ENV_EMPTY)"));
    }
    update_env_info_browser("python_dir", python_exe);
    update_env_info_browser("ITK-SNAP_dir", itk_dir);
    env->deleteLater();
}

void MainWindow::dump_cache()
{
    QSettings cache(cache_dir, QSettings::IniFormat);
    cache.setValue("Environment/python", python_exe);
    cache.setValue("config_dir", config_dir);
    cache.setValue("Terminal/content", ui->terminal->toPlainText());
    cache.setValue("Environment/itk_snap", itk_dir);
    cache.setValue("label_name", label_name);
    cache.sync();
}

bool MainWindow::load_cache()
{
    if (!QFileInfo(cache_dir).exists())
        return false;

    QSettings cache(cache_dir, QSettings::IniFormat);
    python_exe = cache.value("Environment/python").toString();
    update_env_info_browser("python_dir", python_exe);
    if (python_exe.isEmpty())
    {
        ui->terminal->append("python环境不存在，请选择");
    }
    label_name = cache.value("label_name").toString();
    if (label_name.isEmpty())
    {
        QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::CONFIG_ERROR + tr("label_name_NOT_FOUND"));
    }

    independent_input = cache.value("independent_input").toBool();

    config_dir = cache.value("config_dir").toString();
    if (!config_dir.isEmpty())
    {
        QString db_dir = QFileInfo(config_dir).absolutePath() + '/' + QFileInfo(config_dir).baseName() + ".db";
        if (QFileInfo(db_dir).exists())
            update_dataset_list();
        else
            analyze_json_file();
    }
    update_env_info_browser("config_dir", config_dir);
    itk_dir = cache.value("Environment/itk_snap").toString();
    update_env_info_browser("ITK-SNAP_dir", itk_dir);
    QString terminal_content = cache.value("Terminal/content").toString();
    if (terminal_content.isEmpty())
    {
        index_msg = 0;
        init_msg();
    }
    else
        ui->terminal->setText(terminal_content);
    return true;
}

void MainWindow::on_action_clear_terminal_triggered()
{
    ui->terminal->clear();
    index_msg = 0;
    init_msg();
}

void MainWindow::on_action_font_triggered()
{
    bool ok;
    QFont font = QFontDialog::getFont(&ok, QFont(), this, tr("选择字体"));
    if (ok)
    {
        ui->terminal->setFont(font);
        ui->config_info->setFont(QFont(font.family()));
    }
}

void MainWindow::on_action_about_triggered()
{
    QMessageBox::information(this, messageConstants::INFO_TITLE, tr("人在回路(HIL)数据标注平台\n该平台基于Qt 6.9.1与github开源项目(https://github.com/ellisdg/3DUnetCNN.git)开发"));
    return;
}

void MainWindow::on_back_project_manage_clicked()
{
    QSqlDatabase old_db = QSqlDatabase::database();
    if (old_db.isOpen())
    {
        old_db.close();
    }
    QSqlDatabase::removeDatabase(QSqlDatabase::defaultConnection);
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName(QCoreApplication::applicationDirPath() + "/projects.db");
    if (!db.open())
    {
        QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::DATABASE_ERROR + tr("无法打开数据库"));
        return;
    }

    emit back_project_manage();
    this->close();
}

void MainWindow::on_btn_check_annotated_clicked()
{
    int cnt = ui->dataset->topLevelItemCount();
    for (int i = 0; i < cnt; i++)
    {
        QTreeWidgetItem *item = ui->dataset->topLevelItem(i);
        if (item->checkState(2) == Qt::Checked)
            continue;
        int id = item->data(0, Qt::UserRole).toInt();
        QSqlQuery query;
        query.prepare("SELECT img_dir FROM files WHERE id=?");
        query.addBindValue(id);

        if (!query.exec())
        {
            QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::DATABASE_ERROR + "EXEC_FAIL");
            return;
        }
        if (!query.next())
            return;
        QString img_dirs = query.value(0).toString();
        QDir dataset_dir = QFileInfo(img_dirs.split(';')[0]).absoluteDir();
        QString label_dir = QFileInfo(img_dirs.split(';')[0]).absolutePath() + "/" + label_name + ".nii.gz";
        if (dataset_dir.exists(label_dir))
        {
            item->setCheckState(2, Qt::Checked);
        }
    }
}

void MainWindow::update_dataset_status(QTreeWidgetItem *item, int status)
{
    if (status == 0)
    {
        item->setText(1, tr("未标记/空闲集"));
        return;
    }
    if (status == 1)
    {
        item->setText(1, tr("已标记/训练集"));
        return;
    }
    if (status == 2)
    {
        item->setText(1, tr("预测集"));
    }
}

void MainWindow::update_progress_bar(int total, int current)
{
    double progress = (double)current / total;
    progress = (int)(progress * 100);
    ui->progressBar->setValue(progress);
}

void MainWindow::capture_n_epoches(QString output, int &n_epochs)
{
    QRegularExpression n_epoch("Found value '(\\d+)' for key 'n_epochs'");
    QRegularExpressionMatch match = n_epoch.match(output);
    if (match.hasMatch())
    {
        n_epochs = match.captured(1).toInt();
    }
    //  QMessageBox::warning(this, "ERROR", "855");
}

void MainWindow::capture_current_epoch(QString output, int &batch_size, int &current)
{
    QRegularExpression current_epoch("Epoch:\\s*\\[(\\d+)\\]\\[(\\d+)/(\\d+)\\]");
    auto match = current_epoch.globalMatch(output);
    while (match.hasNext())
    {
        auto m = match.next();
        int cur_epoch = m.captured(1).toInt();
        int cur_batch = m.captured(2).toInt();
        int total_batch = m.captured(3).toInt();
        batch_size = total_batch;
        current = total_batch * (cur_epoch - 1) + cur_batch;
    }
    //  QMessageBox::warning(this, "ERROR", "868");
}

void MainWindow::closeEvent(QCloseEvent *event)
{
    dump_cache();
    QMainWindow::closeEvent(event);
}

void MainWindow::capture_prediction_progress(QString output, int &total, int &current)
{
    QRegularExpression total_datasets("Dataset:\\s*(\\d+)");
    QRegularExpression current_dataset("writing:\\s*(.+\\.nii\\.gz)");

    QRegularExpressionMatch total_match = total_datasets.match(output);
    auto current_match = current_dataset.globalMatch(output);

    if (total_match.hasMatch())
    {
        total = total_match.captured(1).toInt();
        return;
    }
    while (current_match.hasNext())
    {
        current_match.next();
        current += 1;
        return;
    }
}

void MainWindow::on_btn_manage_dataset_clicked()
{
    QSettings cache(cache_dir, QSettings::IniFormat);
    QStringList args = cache.value("args", QStringList()).toStringList();
    if (args.isEmpty())
    {
        QMessageBox::warning(this, messageConstants::ERROR_TITLE, tr("管理数据集内容是读取cache失败"));
        return;
    }
    if (args.indexOf("--img_name") + 1 > args.size() - 1 || args.indexOf("--img_name") == -1)
    {
        QMessageBox::warning(this, messageConstants::ERROR_TITLE, tr("配置文件出现错误，请检查模型配置"));
        return;
    }
    QString img_dirs = args[args.indexOf("--img_name") + 1];
    if (img_dirs.startsWith("--"))
    {
        QMessageBox::warning(this, messageConstants::ERROR_TITLE, tr("配置文件出现错误，请检查模型配置"));
        return;
    }

    QStringList dirs = img_dirs.split(",");
    QStringList names;
    for (QString dir : dirs)
    {
        names << dir + ".nii.gz";
    }

    if (args.indexOf("--img_dir") + 1 > args.size() - 1 || args.indexOf("--img_dir") == -1)
    {
        QMessageBox::warning(this, messageConstants::ERROR_TITLE, tr("配置文件出现错误，请检查模型配置"));
        return;
    }
    QString dataset_dir = args[args.indexOf("--img_dir") + 1];
    if (dataset_dir.startsWith("--"))
    {
        QMessageBox::warning(this, messageConstants::ERROR_TITLE, tr("配置文件出现错误，请检查模型配置"));
        return;
    }
    // for (QString dir : dirs)
    //     QFileInfo info(dir);
    // names << info.fileName();
    // QDir path = info.dir();
    // path.cdUp();
    // dataset_dir = path.absolutePath();

    manageDatasets *md = new manageDatasets(this, dataset_dir, names, label_name + ".nii.gz ", QFileInfo(config_dir).absolutePath(), independent_input);
    md->exec();
    md->deleteLater();
    update_dataset_list();
}

void MainWindow::on_dataset_right_clicked(const QPoint &pos)
{
    QTreeWidgetItem *clicked_item = ui->dataset->itemAt(pos);
    if (!clicked_item)
        return;
    // if (clicked_item->checkState(2) == Qt::Checked) return;
    QList<QTreeWidgetItem *> selected_items = ui->dataset->selectedItems();
    if (!selected_items.contains(clicked_item))
    {
        ui->dataset->clearSelection();
        clicked_item->setSelected(true);
        selected_items.clear();
        selected_items.append(clicked_item);
    }
    QMenu menu(this);
    QAction *as_prediction = menu.addAction(tr("移至预测集"));
    QAction *as_training = menu.addAction(tr("移至训练集"));
    QAction *as_rest = menu.addAction(tr("移至空闲集"));
    QAction *selected_action = menu.exec(ui->dataset->viewport()->mapToGlobal(pos));
    for (QTreeWidgetItem *item : selected_items)
    {
        if (selected_action == as_prediction)
        {
            item->setCheckState(3, Qt::Checked);
        }
        else if (selected_action == as_training)
        {
            item->setCheckState(2, Qt::Checked);
        }
        else if (selected_action == as_rest)
        {
            item->setCheckState(3, Qt::Unchecked);
            item->setCheckState(2, Qt::Unchecked);
        }
        // item->setSelected(false);
    }
}

void MainWindow::filter_datasets(const QString &text)
{
    for (int i = 0; i < ui->dataset->topLevelItemCount(); ++i)
    {
        QTreeWidgetItem *item = ui->dataset->topLevelItem(i);
        bool match = item->text(0).contains(text);
        item->setHidden(!match);
    }
}

void MainWindow::clear_search_result()
{
    ui->serach->clear();
    filter_datasets("");
}

void MainWindow::block_dataset_change()
{
    for (int i = 0; i < ui->dataset->topLevelItemCount(); ++i)
    {
        QTreeWidgetItem *item = ui->dataset->topLevelItem(i);
        item->setFlags(item->flags() & ~Qt::ItemIsUserCheckable);
    }
    ui->dataset->setContextMenuPolicy(Qt::NoContextMenu);
    ui->btn_check_annotated_datasets->setEnabled(false);
    ui->btn_manage_dataset->setEnabled(false);
}

void MainWindow::recover_dataset_change()
{
    for (int i = 0; i < ui->dataset->topLevelItemCount(); ++i)
    {
        QTreeWidgetItem *item = ui->dataset->topLevelItem(i);
        item->setFlags(item->flags() | Qt::ItemIsUserCheckable);
    }
    ui->dataset->setContextMenuPolicy(Qt::CustomContextMenu);
    ui->btn_check_annotated_datasets->setEnabled(true);
    ui->btn_manage_dataset->setEnabled(true);
}

void MainWindow::copy_models()
{
    QString project_dir = QFileInfo(config_dir).absolutePath();
    if (!copy_files(project_dir + "/training_output/config", project_dir + "/model"))
    {
        QMessageBox::warning(this, messageConstants::ERROR_TITLE, tr("移动模型失败"));
        return;
    }
    if (QFile::exists(project_dir + "/training_output/config"))
    {
        if (!QDir(project_dir + "/training_output/config").removeRecursively())
        {
            QMessageBox::warning(this, messageConstants::ERROR_TITLE, tr("清理模型失败"));
            return;
        }
    }
}

bool MainWindow::copy_files(const QString &src, const QString &des)
{
    QDir src_dir(src);
    if (!src_dir.exists())
    {
        return false;
    }
    QDir().mkpath(des);

    QDirIterator it(src, QDir::Files | QDir::Dirs | QDir::NoDotAndDotDot, QDirIterator::Subdirectories);
    while (it.hasNext())
    {
        QString src_item = it.next();
        QFileInfo src_info(src_item);

        QString relative_path = src_dir.relativeFilePath(src_item);
        QString dest_item = des + "/" + relative_path;
        if (src_info.isDir())
        {
            QDir().mkpath(dest_item);
        }
        else if (src_info.isFile())
        {
            QDir().mkpath(QFileInfo(dest_item).absolutePath());
            if (QFile::exists(dest_item))
            {
                QFile::remove(dest_item);
            }
            if (!QFile::copy(src_item, dest_item))
            {
                return false;
            }
        }
    }
    return true;
}

void MainWindow::on_action_dcm_2_nii_triggered()
{
    dcm2nii *d2n = new dcm2nii(this, python_exe);
    d2n->exec();
    d2n->deleteLater();
}

void MainWindow::on_action_export_ipp_triggered()
{
    exportIPP *eip = new exportIPP(this, python_exe, QFileInfo(config_dir).absolutePath(), independent_input);
    eip->exec();
    eip->deleteLater();
}
