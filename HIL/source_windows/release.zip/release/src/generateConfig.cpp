#include "generateConfig.h"

generateConfig::generateConfig(QWidget *parent,QString python_env,QString cache_dir)
    : QDialog{parent},ui(new Ui::generateConfig), error_msg("")
{
    ui->setupUi(this);
    this->setFixedSize(510,335);
    this->setWindowTitle("生成配置文件");
    connect_signals();
    load_cache(cache_dir);
    python_exe = python_env;
    this->cache_dir = cache_dir;
    advanced_settings(false);
}

generateConfig::~generateConfig() {
    delete ui;
}

void generateConfig::connect_signals() {
    connect(ui->btn_img_browse, &QPushButton::clicked, this, &generateConfig::get_dataset_dir);
    connect(ui->btn_browse_config_dir, &QPushButton::clicked, this, &generateConfig::get_output_dir);
    connect(ui->btn_ok, &QPushButton::clicked, this, &generateConfig::btn_ok_pressed);
    connect(ui->btn_cancel, &QPushButton::clicked, this, &generateConfig::btn_cancel_pressed);
    connect(ui->showAllSettings, &QCheckBox::checkStateChanged, this, &generateConfig::btn_show_all_settings_clicked);
    connect(ui->browse_image, &QPushButton::clicked, this, &generateConfig::on_browse_images_clicked);
    connect(ui->browsw_label, &QPushButton::clicked, this, &generateConfig::on_browse_label_clicked);
    connect(ui->independent_input, &QCheckBox::checkStateChanged, this, &generateConfig::on_independent_input_checked);
    
}

void generateConfig::advanced_settings(bool if_show) {
    if (!if_show) {
        this->setFixedSize(510, 335);
        ui->model->hide();
        ui->optimizer->hide();
        ui->loss->hide();
        ui->cross_validation->hide();
        ui->scheduler->hide();
        ui->dataset->hide();
        ui->training->hide();
    }
    else {
        this->setFixedSize(510, 800);
        ui->model->show();
        ui->optimizer->show();
        ui->loss->show();
        ui->cross_validation->show();
        ui->scheduler->show();
        ui->dataset->show();
        ui->training->show();
    }
}

void generateConfig::get_model_args() {
    QString model_name = ui->model_name->currentText();
    qint64 in_channels = ui->in_channels->value();
    qint64 out_channels = ui->out_channels->value();
    qint64 depth = ui->depth->value();
    bool deep_supervision = ui->deep_supervision->isChecked();
    qint64 spatial_dims = ui->spatial_dims->value();
    bool independent_input = ui->independent_input->isChecked();

    args << "--model_name" << model_name;
    args << "--in_channels" << QString::number(in_channels);
    args << "--out_channels" << QString::number(out_channels);
    args << "--depth" << QString::number(depth);
    args << "--deep_supervision" << (deep_supervision ? "true" : "false");
    args << "--spatial_dims" << QString::number(spatial_dims);
    args << "--independent_input" << (independent_input ? "true" : "false");
}

void generateConfig::get_optimizer_args() {
    QString optimizer_name = ui->optimizer_name->currentText();
    qint64 lr_rate = ui->lr_rate->value();

    args << "--optimizer_name" << optimizer_name;
    args << "--lr_rate" << QString::number(lr_rate);
}

void generateConfig::get_loss_args() {
    QString loss_name = ui->loss_name->currentText();
    bool include_bg = ui->include_background->isChecked();
    QString act_func = ui->activation->currentText();

    args << "--loss_name" << loss_name;
    args << "--include_bg" << (include_bg ? "true" : "false");
    args << "--act_func" << act_func;
}

void generateConfig::get_cross_validation_args() {
    bool enable_cross_validation = ui->Enable_cross_validation->isChecked();
    qint64 folds = ui->folds->value();
    qint64 seed = ui->seed->value();

    args << "--enable_cross_validation" << (enable_cross_validation ? "true" : "false");
    if (enable_cross_validation) {
        args << "--n_folds" << QString::number(folds);
        args << "--seed" << QString::number(seed);
    }
}

void generateConfig::get_scheduler_args() {
    QString scheduler_name = ui->scheduler_name->currentText();
    qint64 patience = ui->patience->value();
    QString factor = ui->lineEdit->text();
    qint64 min_lr_rate = ui->min_learning_rate->value();

    args << "--scheduler_name" << scheduler_name;
    args << "--patience" << QString::number(patience);
    args << "--factor" << factor;
    args << "--min_lr_rate" << QString::number(min_lr_rate);
}

void generateConfig::get_dataset_args() {
    QString dataset_name = ui->dataset_name->currentText();
    qint64 shape_x = ui->shape_x->value();
    qint64 shape_y = ui->shape_y->value();
    qint64 shape_z = ui->shape_z->value();
    QString labels = ui->labels->text();
    bool setup_label_hierarchy = ui->setup_label_hierarchy->isChecked();
    QString normalization = ui->normalization->currentText();
    bool channel_wise = ui->channel_wise->isChecked();
    bool nonzero = ui->nonzero->isChecked();
    bool resample = ui->resample->isChecked();
    bool crop_foreground = ui->crop_fore_ground->isChecked();
    QString img_dir = ui->img_directories->text();
    QString img_name = ui->img_name->text();
    QString label_name = ui->label_name->text();
    bool gen_com_label = ui->gen_combined_label->isChecked();

    args << "--dataset_name" << dataset_name;
    args << "--shape_x" << QString::number(shape_x);
    args << "--shape_y" << QString::number(shape_y);
    args << "--shape_z" << QString::number(shape_z);
    args << "--labels" << labels;
    args << "--setup_label_hierarchy" << (setup_label_hierarchy ? "true" : "false");
    args << "--normalization" << normalization;
    args << "--channel_wise" << (channel_wise ? "true" : "false");
    args << "--nonzero" << (nonzero ? "true" : "false");
    args << "--resample" << (resample ? "true" : "false");
    args << "--crop_foreground" << (crop_foreground ? "true" : "false");
    args << "--img_dir" << img_dir;
    args << "--img_name" << img_name;
    args << "--label_name" << label_name;
    args << "--gen_com_label" << (gen_com_label ? "true" : "false");
}

void generateConfig::get_training_args() {
    qint64 batch_size = ui->batch_size->value();
    qint64 validation_batch_size = ui->validation_batch_size->value();
    bool amp = ui->amp->isChecked();
    qint64 early_stopping_patience = ui->early_stopping_patience->value();
    qint64 n_epochs = ui->n_epochs->value();
    qint64 save_every_n_epochs = ui->save_every_n_epochs->value();
    qint64 save_last_n_models = ui->save_last_n_models->value();
    bool save_best = ui->save_best->isChecked();

    args << "--batch_size" << QString::number(batch_size);
    args << "--validation_batch_size" << QString::number(validation_batch_size);
    args << "--amp" << (amp ? "true" : "false");
    args << "--early_stopping_patience" << QString::number(early_stopping_patience);
    args << "--n_epochs" << QString::number(n_epochs);
    args << "--save_every_n_epochs" << QString::number(save_every_n_epochs);
    args << "--save_last_n_models" << QString::number(save_last_n_models);
    args << "--save_best" << (save_best ? "true" : "false");
}

void generateConfig::get_dataset_dir() {
    QFileDialog* dialog = new QFileDialog();
    QString dir = dialog->getExistingDirectory(this, DialogTitles::SELECT_DATASET_DIR, QDir::homePath());
    if (!dir.isEmpty()) {
        ui->img_directories->setText(dir);
    }

}

void generateConfig::get_output_dir() {
    QFileDialog* dialog = new QFileDialog();
    QString dir=dialog->getExistingDirectory(this, DialogTitles::SELECT_JSON_FILE, QDir::homePath());
    if (dir.isEmpty()) return;
    dir = dir + "/config.json";
    if (!QFile::exists(dir)) {
        QFile file(dir);
        if (file.open(QIODevice::WriteOnly)) {
            file.close();
        }
        else {
            QMessageBox::warning(this, messageConstants::ERROR_TITLE, "无法创建文件，请重试");
            return;
        }
    }
    ui->config_directories->setText(dir);
}

void generateConfig::btn_cancel_pressed() {
    args.clear();
    this->close();
}

void generateConfig::btn_ok_pressed() {
    if (!input_validation()) return;
    args.clear();
    args << QCoreApplication::applicationDirPath()+"/scripts/generateConfig.py";
    get_model_args();
    get_optimizer_args();
    get_loss_args();
    get_cross_validation_args();
    get_scheduler_args();
    get_dataset_args();
    get_training_args();
    args << "--output_dir" << ui->config_directories->text();
    
    // QMessageBox::information(this, "Debug", args.join(" "));
    dump_cache(cache_dir);
    run_script();
}

bool generateConfig::input_validation() {
    if (ui->img_directories->text().isEmpty()) {
        QMessageBox::warning(this, messageConstants::WARNING_TITLE, tr("请输入数据集路径"));
        return false;
    }
    if (ui->img_name->text().isEmpty()) {
        QMessageBox::warning(this, messageConstants::WARNING_TITLE, tr("请输入CT图像名"));
        return false;
    }
    if (ui->label_name->text().isEmpty()) {
        QMessageBox::warning(this, messageConstants::WARNING_TITLE, tr("请输入CT图像名分割图像名"));
        return false;
    }
    if (ui->labels->text().isEmpty()) {
        QMessageBox::warning(this, messageConstants::WARNING_TITLE, tr("请输入分割标签"));
        return false;
    }
    return true;
}

void generateConfig::run_script() {
    QProcess* gen_config = new QProcess(this);

    QProgressDialog* waiting_for_finished = new QProgressDialog("正在生成配置...", "", 0, 0, this);
    waiting_for_finished->setWindowTitle("请稍等");
    waiting_for_finished->setWindowModality(Qt::WindowModal);
    waiting_for_finished->setCancelButton(nullptr);
    waiting_for_finished->setMinimumDuration(0);
    waiting_for_finished->move(this->geometry().center() - waiting_for_finished->rect().center());

    connect(gen_config, &QProcess::started, this, [=] {
        this->on_process_started(waiting_for_finished);
        });
    connect(gen_config, QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished), this, [=](int exitcode, QProcess::ExitStatus exitstatus) {
        this->on_process_finished(exitcode,exitstatus,waiting_for_finished);
        });
    connect(gen_config, &QProcess::readyReadStandardError, this, [=]() {
        QByteArray error = gen_config->readAllStandardError();
        error_msg.append(error);
        });
    gen_config->start(python_exe, args);
}

void generateConfig::on_process_started(QProgressDialog* msg_box) {
    msg_box->show();
}

void generateConfig::on_process_finished(int code, QProcess::ExitStatus status, QProgressDialog* msg_box) {
    msg_box->close();
    msg_box->deleteLater();
    if (code == 0) {
        QMessageBox::information(this, messageConstants::SUCCESS_TITLE, "生成成功");
        emit send_config_dir(ui->config_directories->text(),(ui->gen_combined_label->checkState()==Qt::Checked)?"combined_label":ui->label_name->text());
        this->close();
    }
    else {
        QMessageBox::warning(this, messageConstants::ERROR_TITLE, error_msg);
    }
}

void generateConfig::dump_cache(QString dir) {
    QSettings cache(dir, QSettings::IniFormat);
    cache.setValue("args", args);
    cache.setValue("independent_input", ui->independent_input->isChecked());
    cache.sync();
}

void generateConfig::load_cache(QString dir) {
    if (!QFile::exists(dir)) return;
    QSettings cache(dir, QSettings::IniFormat);
    QStringList cache_args = cache.value("args", QStringList()).toStringList();
    for (int i = 1; i < cache_args.size(); i += 2) {
        if (!cache_args[i].startsWith("--")) continue;
        QString key = cache_args[i].mid(2);
        QString val = (i + 1 < cache_args.size() ? cache_args[i + 1] : "");
        set_value_from_cache(key, val);
    }
}

void generateConfig::set_value_from_cache(QString key, QString val) {
    if (key == "model_name") ui->model_name->setCurrentText(val);
    else if (key == "in_channels") ui->in_channels->setValue(val.toInt());
    else if (key == "out_channels") ui->out_channels->setValue(val.toInt());
    else if (key == "depth") ui->depth->setValue(val.toInt());
    else if (key == "deep_supervision") ui->deep_supervision->setChecked(val == "true");
    else if (key == "spatial_dims") ui->spatial_dims->setValue(val.toInt());

    else if (key == "optimizer_name") ui->optimizer_name->setCurrentText(val);
    else if (key == "lr_rate") ui->lr_rate->setValue(val.toInt());

    else if (key == "loss_name") ui->loss_name->setCurrentText(val);
    else if (key == "include_bg") ui->include_background->setChecked(val == "true");
    else if (key == "act_func") ui->activation->setCurrentText(val);

    else if (key == "enable_cross_validation") ui->Enable_cross_validation->setChecked(val == "true");
    else if (key == "n_folds") ui->folds->setValue(val.toInt());
    else if (key == "seed") ui->seed->setValue(val.toInt());

    else if (key == "scheduler_name") ui->scheduler_name->setCurrentText(val);
    else if (key == "patience") ui->patience->setValue(val.toInt());
    else if (key == "factor") ui->lineEdit->setText(val);
    else if (key == "min_lr_rate") ui->min_learning_rate->setValue(val.toInt());

    else if (key == "dataset_name") ui->dataset_name->setCurrentText(val);
    else if (key == "shape_x") ui->shape_x->setValue(val.toInt());
    else if (key == "shape_y") ui->shape_y->setValue(val.toInt());
    else if (key == "shape_z") ui->shape_z->setValue(val.toInt());
    else if (key == "labels") ui->labels->setText(val);
    else if (key == "setup_label_hierarchy") ui->setup_label_hierarchy->setChecked(val == "true");
    else if (key == "normalization") ui->normalization->setCurrentText(val);
    else if (key == "channel_wise") ui->channel_wise->setChecked(val == "true");
    else if (key == "nonzero") ui->nonzero->setChecked(val == "true");
    else if (key == "resample") ui->resample->setChecked(val == "true");
    else if (key == "crop_foreground") ui->crop_fore_ground->setChecked(val == "true");
    else if (key == "img_dir") ui->img_directories->setText(val);
    else if (key == "img_name") ui->img_name->setText(val);
    else if (key == "label_name") ui->label_name->setText(val);
    else if (key == "gen_com_label") ui->gen_combined_label->setChecked(val == "true");
    //else if (key == "output_dir") ui->config_directories->setText(val);

    else if (key == "batch_size") ui->batch_size->setValue(val.toInt());
    else if (key == "validation_batch_size") ui->validation_batch_size->setValue(val.toInt());
    else if (key == "amp") ui->amp->setChecked(val == "true");
    else if (key == "early_stopping_patience") ui->early_stopping_patience->setValue(val.toInt());
    else if (key == "n_epochs") ui->n_epochs->setValue(val.toInt());
    else if (key == "save_every_n_epochs") ui->save_every_n_epochs->setValue(val.toInt());
    else if (key == "save_last_n_models") ui->save_last_n_models->setValue(val.toInt());
    else if (key == "save_best") ui->save_best->setChecked(val == "true");
    else if (key == "independent_input") ui->independent_input->setChecked(val == "true");
}

void generateConfig::btn_show_all_settings_clicked(Qt::CheckState is_checked) {
    if (is_checked == Qt::Checked) advanced_settings(true);
    else advanced_settings(false);
}

void generateConfig::on_browse_images_clicked() {
    QString dataset_root_dir = ui->img_directories->text();
    if (dataset_root_dir.isEmpty()) {
        QMessageBox::warning(this, messageConstants::WARNING_TITLE, tr("请先选择数据集路径"));
        return;
    }
    
    datasets* browser_img = new datasets(this, tr("选择CT文件"), dataset_root_dir, ui->img_name->text(), ui->label_name->text());
    connect(browser_img, &datasets::send_datasets, this, [=](QString selected_datasets) {
        ui->img_name->setText(selected_datasets);
        });
    browser_img->exec();
    return;
}

void generateConfig::on_browse_label_clicked(){
    QString dataset_root_dir = ui->img_directories->text();
    if (dataset_root_dir.isEmpty()) {
        QMessageBox::warning(this, messageConstants::WARNING_TITLE, tr("请先选择数据集路径"));
        return;
    }
    
    datasets* browser_label = new datasets(this, tr("选择分割文件"), dataset_root_dir, ui->label_name->text(), ui->img_name->text());
    connect(browser_label, &datasets::send_datasets, this, [=](QString selected_datasets) {
        ui->label_name->setText(selected_datasets);
        });
    browser_label->exec();
    return;
}

datasets::datasets(QWidget* parent,QString window_title,QString dataset_root_dir,QString added_img_files,QString added_label_files) :QDialog(parent),d_ui(new Ui::manageDatasets) {
    d_ui->setupUi(this);
    d_ui->treeWidget->setColumnCount(2);
    d_ui->treeWidget->setHeaderLabels(QStringList() << tr("数据集") << "");
    d_ui->treeWidget->setColumnWidth(0, 200);
    d_ui->treeWidget->setSortingEnabled(true);

    this->setWindowTitle(window_title);
    this->dataset_root_dir = dataset_root_dir;
    this->added_img_files = added_img_files.replace("，", ",").split(",");
    this->added_label_files = added_label_files.replace("，", ",").split(",");
    connect(d_ui->btn_ok, &QPushButton::clicked, this, &datasets::on_btn_ok_clicked);
    connect(d_ui->btn_refresh, &QPushButton::clicked, this, &datasets::on_btn_refresh_clicked);

    on_btn_refresh_clicked();
}

datasets::~datasets(){
    delete d_ui;
}

QSet<QString> datasets::search_nii_files(QString dataset_root_dir) {
    QDir dirs(dataset_root_dir);
    QFileInfoList datasets = dirs.entryInfoList(QDir::Dirs | QDir::NoDotAndDotDot);
    QSet<QString> nii_files;
    for (QFileInfo dataset : datasets) {
        QDir dir(dataset.absoluteFilePath());
        dir.setNameFilters(QStringList() << "*.nii.gz");
        QFileInfoList files = dir.entryInfoList(QDir::Files | QDir::NoDotAndDotDot);
        for (QFileInfo file : files) {
            nii_files.insert(file.baseName());
        }
    }
    return nii_files;
}

void datasets::init() {
    QSet<QString> nii_files = search_nii_files(dataset_root_dir);
    for (QString file : nii_files) {
        QTreeWidgetItem* item = new QTreeWidgetItem(d_ui->treeWidget);
        if (added_label_files.contains(file)) {
            item->setText(0, file);
            item->setCheckState(0, Qt::Unchecked);
            item->setFlags(item->flags() & ~Qt::ItemIsUserCheckable);
            item->setText(1, tr("已放入另一分类,无法选中"));
            continue;
        }
        item->setFlags(item->flags() | Qt::ItemIsUserCheckable);
        item->setText(0,file);
        if (added_img_files.contains(file)) {
            item->setCheckState(0, Qt::Checked);
        }
        else {
            item->setCheckState(0, Qt::Unchecked);
        }
    }
}

void datasets::on_btn_ok_clicked() {
    int num = d_ui->treeWidget->topLevelItemCount();
    QStringList selected;
    for (int i = 0;i < num;++i) {
        QTreeWidgetItem* item = d_ui->treeWidget->topLevelItem(i);
        if(item->checkState(0)==Qt::Checked){
            selected << item->text(0);
        }
    }
    emit send_datasets(selected.join(','));
    this->close();
}

void datasets::on_btn_refresh_clicked() {
    d_ui->treeWidget->clear();
    init();
}

void generateConfig::on_independent_input_checked(Qt::CheckState state) {
    if (state == Qt::Checked) {
        ui->in_channels->setValue(1);
        ui->in_channels->setEnabled(false);
    } else {
        ui->in_channels->setEnabled(true);
    }
}
