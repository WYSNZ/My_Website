#include "exportIPP.h"

exportIPP::exportIPP(QWidget *parent, QString python, QString project_dir, bool independent)
    : QDialog{parent},ui(new Ui::exportIPP)
{
    ui->setupUi(this);
    this->project_dir = project_dir;
    this->python = python;
    this->independent = independent;
    connect(ui->btn_browse_output_dir, &QPushButton::clicked, this, &exportIPP::on_btn_browse_output_dir_clicked);
    connect(ui->btn_ok, &QPushButton::clicked, this, &exportIPP::on_btn_ok_clicked);
    connect(ui->btn_cancel, &QPushButton::clicked, this, &exportIPP::close);

    init();
}
exportIPP::~exportIPP()
{
    delete ui;
}
void exportIPP::init()
{
    QString config_dir = project_dir + "/config.json";
    QString model_dir = project_dir + "/model/model_best.pth";
    if (QFile::exists(config_dir)) {
        ui->config_dir->setText(config_dir);
    }
    if (QFile::exists(model_dir)) {
        ui->model_dir->setText(model_dir);
    }
}

void exportIPP::on_btn_browse_output_dir_clicked()
{
    QString output_dir = QFileDialog::getExistingDirectory(this, "选择输出文件夹");
    ui->output_dir->setText(output_dir);
}

void exportIPP::on_btn_ok_clicked()
{
    QString config = ui->config_dir->text();
    QString model = ui->model_dir->text();
    QString output = ui->output_dir->text();
    if (config.isEmpty() || model.isEmpty() || output.isEmpty()) {
        QMessageBox::warning(this,tr("警告"), tr("请填写完整信息"));
        return;
    }
    if (!QFileInfo(config).exists() || !QFileInfo(model).exists()) {
        ui->terminal->append(tr("模型或配置文件不存在，无法转换"));
        return;
    }
    if (!QFileInfo(output).exists()) {
        if (!QDir().mkpath(output)) {
            QMessageBox::warning(this,tr("警告"), tr("输出目录创建失败"));
            return;
        }
    }
    QSettings settings(output + "/settings.ini", QSettings::IniFormat, this);
    settings.setValue("independent", independent);
    QProcess* process = new QProcess(this);
    QStringList args;
    args << QCoreApplication::applicationDirPath() + "/scripts/pth2onnx.py";
    args<<"--config_path"<<config;
    args<<"--model_path"<<model;
    args << "--output_onnx_path" << output + "/model.onnx";
    args << "--template_exe_dir" << QCoreApplication::applicationDirPath() + "/template_HIL_IPP";
    connect(process, &QProcess::started, this, [this]() {
        ui->terminal->append(tr("模型转换开始"));
        });
    connect(process, &QProcess::finished, this, [this,process](int code, QProcess::ExitStatus status) {
        if (code == 0 && status == QProcess::NormalExit) {
            ui->terminal->append(tr("模型转换成功"));
            process->deleteLater();
            QTimer::singleShot(3000, this, &QDialog::close);
        }
        else {
            ui->terminal->append(tr("模型转换失败"));
        }

        });
    connect(process, &QProcess::readyReadStandardOutput, this, [this, process]() {
        ui->terminal->append(QString::fromLocal8Bit(process->readAllStandardOutput()));
        });
    connect(process, &QProcess::readyReadStandardError, this, [this, process]() {
        ui->terminal->append(QString::fromLocal8Bit(process->readAllStandardError()));
        });
    process->start(python, args);
}

void exportIPP::on_btn_cancel_clicked()
{
    this->close();
}
