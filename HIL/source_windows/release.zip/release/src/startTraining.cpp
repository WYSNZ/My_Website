#include "startTraining.h"
#include "constants.h"
startTraining::startTraining(QWidget* parent,QString project_dir)
    : QDialog{ parent }, ui(new Ui::startTraining) {
    ui->setupUi(this);
    this->setWindowTitle(tr("训练参数"));
    connect(ui->btn_ok, &QPushButton::clicked, this, &startTraining::on_ok_clicked);
    connect(ui->btn_cancel, &QPushButton::clicked, this, &startTraining::on_cancel_clicked);
    connect(ui->btn_browse, &QPushButton::clicked, this, &startTraining::on_browse_clicked);
    this->project_dir = project_dir;
    auto_set_output_dir();
}
startTraining::~startTraining() {
    delete ui;
}
void startTraining::on_ok_clicked() {
    ngpus = ui->ngpus->value();
    nthreads = ui->nthreads->value();
    if (ngpus == 0 || nthreads == 0 || output_dir.isEmpty()) {
        QMessageBox::warning(this, messageConstants::FILE_NOT_FOUND, messageConstants::VALIDATION_FAIL);
        return;
    }
    this->accept();
}
void startTraining::on_cancel_clicked() {
    this->reject();
}

void startTraining::on_browse_clicked() {
    output_dir = QFileDialog::getExistingDirectory(this, DialogTitles::SELECT_OUTPUT_DIR, QDir::homePath());
    ui->model_path->setText(output_dir);
}

void startTraining::closeEvent(QCloseEvent* event) {
    event->accept();
    this->reject();
}

void startTraining::auto_set_output_dir() {
    QString training_output = project_dir + "/training_output";
    QDir dir;
    if (!dir.exists(training_output)) {
        if (!dir.mkpath(training_output)) {
            QMessageBox::warning(this, messageConstants::ERROR_TITLE, tr("文件夹创建失败: ") + training_output);
            return;
        }
    }
    output_dir = training_output;
    ui->model_path->setText(output_dir);

    QString model_dir = project_dir + "/model";
    if (!dir.exists(model_dir)) {
        if (!dir.mkpath(model_dir)) {
            QMessageBox::warning(this, messageConstants::ERROR_TITLE, tr("文件夹创建失败: ") + training_output);
            return;
        }
    }
}

