#include "itemDoubleClick.h"
#include "constants.h"
itemDoubleClick::itemDoubleClick(QWidget* parent, QString img_dir, QString label_dir, QString label_name, QString itk_dir)
    : QDialog{ parent }, ui(new Ui::itemDoubleClick), _img_dir(img_dir), _label_dir(label_dir), _label_name(label_name),
    _itk_dir(itk_dir) {
    ui->setupUi(this);
    init();
    this->setWindowTitle("数据集详情");
    connect(ui->file_browser, &QTreeWidget::itemDoubleClicked, this, &itemDoubleClick::on_item_double_clicked);
    connect(ui->btn_refresh, &QPushButton::clicked, this, &itemDoubleClick::on_btn_refresh_clicked);
    ui->load_label->setChecked(true);
}
itemDoubleClick::~itemDoubleClick() {
    delete ui;
}
void itemDoubleClick::init() {
    ui->file_browser->clear();
    QStringList img_dirs = _img_dir.split(';');
    QString path = QFileInfo(img_dirs[0]).absolutePath();
    ui->file_browser->setHeaderLabel(path);

    QList<QTreeWidgetItem*> items;
    QTreeWidgetItem* imgs = new QTreeWidgetItem(ui->file_browser);
    imgs->setText(0, "images");
    for (QString dir : img_dirs) {
        QTreeWidgetItem* item = new QTreeWidgetItem(imgs);
        item->setText(0, QFileInfo(dir).baseName() + ".nii.gz");
        item->setData(0, Qt::UserRole, dir);
        items.append(item);
    }
    if (!_label_dir.isEmpty()) {
        QTreeWidgetItem* label_header = new QTreeWidgetItem(ui->file_browser);
        label_header->setText(0, "label");
        QTreeWidgetItem* label = new QTreeWidgetItem(label_header);
        label->setText(0, QFileInfo(_label_dir).baseName() + ".nii.gz");
        label->setData(0, Qt::UserRole, _label_dir);
    }
    else {
        QString label = search_label_files(path);
        if (!label.isEmpty()) {
            _label_dir = label;

            QTreeWidgetItem* label_header = new QTreeWidgetItem(ui->file_browser);
            label_header->setText(0, "label");
            QTreeWidgetItem* _a = new QTreeWidgetItem(label_header);
            _a->setText(0, QFileInfo(label).baseName() + ".nii.gz");
            _a->setData(0, Qt::UserRole, label);
        }
    }

}
//打开itksnap只能通过点击exe运行实现，ide内的环境变量无法满足要求
void itemDoubleClick::on_item_double_clicked(QTreeWidgetItem* item, int column) {
    QString filename = item->data(0, Qt::UserRole).toString();
    if (!QFileInfo(filename).exists()) {
        QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::FILE_NOT_FOUND + filename);
        return;
    }
    if (_itk_dir.isEmpty()) {
        QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::FILE_NOT_FOUND + _itk_dir);
        QDesktopServices::openUrl(QUrl::fromLocalFile(filename));
        return;
    }
    QStringList args;
    args << "-g";
    if (QFileInfo(filename).baseName() == _label_name) {
        args << filename;
        if (!QProcess::startDetached(_itk_dir, args)) {
            QMessageBox::warning(this, messageConstants::ERROR_TITLE, tr("无法打开文件: ") + filename);
        }
    }
    else {
        args << filename;
        if (ui->load_label->isChecked() &&!_label_dir.isEmpty()) {
            args << "-s" << _label_dir;
        }
        if (!QProcess::startDetached(_itk_dir, args)) {
            QMessageBox::warning(this, messageConstants::ERROR_TITLE, tr("无法打开文件: ") + filename);
        }
    }
}

QString itemDoubleClick::search_label_files(QString path) {
    QString l_path = path + "/" + _label_name + ".nii.gz";
    if (QFileInfo::exists(l_path)) {
        return l_path;
    }
    return "";
}

void itemDoubleClick::on_btn_refresh_clicked() {
    init();
}