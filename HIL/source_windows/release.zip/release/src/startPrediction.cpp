#include "startPrediction.h"
#include "constants.h"

startPrediction::startPrediction(QWidget *parent,QString project_dir)
    : QDialog{parent},ui(new Ui::startPrediction)
{
    ui->setupUi(this);
    this->setWindowTitle(tr("预测参数"));
    connect(ui->btn_browse_output, &QPushButton::clicked, this, &startPrediction::btn_browse_output_clicked);
    connect(ui->btn_browse_model, &QPushButton::clicked, this, &startPrediction::btn_browse_model_clicked);
    connect(ui->btn_ok, &QPushButton::clicked, this, &startPrediction::btn_ok_clicked);
    connect(ui->btn_cancel, &QPushButton::clicked, this, &startPrediction::btn_cancel_clicked);
    this->project_dir = project_dir;
    auto_set_model();
    auto_set_output_dir();
}
startPrediction::~startPrediction() {
    delete ui;
}

void startPrediction::btn_browse_output_clicked() {
    output_dir=QFileDialog::getExistingDirectory(this, DialogTitles::SELECT_OUTPUT_DIR, QDir::homePath());
    ui->output_dir->setText(output_dir);
}

void startPrediction::btn_browse_model_clicked() {
    model_dir = QFileDialog::getOpenFileName(this, DialogTitles::SELECT_MODEL_FILE, QDir::homePath(), "pth模型文件(*.pth);;所有文件(*.*)");
    ui->model_dir->setText(model_dir);
}

void startPrediction::btn_ok_clicked() {
    ngpus = ui->ngpus->value();
    nthreads = ui->nthreads->value();
    if (output_dir.isEmpty() || model_dir.isEmpty() || ngpus == 0 || nthreads == 0) {
        QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::VALIDATION_FAIL);
        return;
    }
    this->accept();
}

void startPrediction::btn_cancel_clicked() {
    this->reject();
}

void startPrediction::closeEvent(QCloseEvent* event) {
    event->accept();
    this->reject();
}

void startPrediction::auto_set_model() {
    QString dir = project_dir + "/model/model_best.pth";
    if (!QFileInfo(dir).exists()) {
        return;
    }
    model_dir = dir;
    ui->model_dir->setText(model_dir);
}

void startPrediction::auto_set_output_dir() {
    QString pre_output = project_dir + "/raw_output";
    QDir dir;
    if (!dir.exists(pre_output)) {
        if (!dir.mkpath(pre_output)) {
            QMessageBox::warning(this, messageConstants::ERROR_TITLE, tr("文件夹创建失败: ") + pre_output);
            return;
        }
    }
    output_dir = pre_output;
    ui->output_dir->setText(output_dir);
}