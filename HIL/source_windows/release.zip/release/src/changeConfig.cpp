#include "changeConfig.h"


changeConfig::changeConfig(QWidget* parent, QString json_file, QString cache_dir)
    : QDialog{ parent }, ui(new Ui::changeConfig), json(json_file), cache_dir(cache_dir) {
    ui->setupUi(this);
    load_json(json_file);
    ui->showAllSettings->setChecked(false);
    ui->config_directories->setText(json_file);
    ui->config_directories->setEnabled(false);
    connect(ui->btn_ok, &QPushButton::clicked, this, &changeConfig::btn_ok_clicked);
    connect(ui->btn_cancel, &QPushButton::clicked, this, &changeConfig::btn_cancel_clicked);
    connect(ui->showAllSettings, &QCheckBox::checkStateChanged, this, &changeConfig::btn_show_all_settings_clicked);
    advanced_settings(false);
    this->setWindowTitle(tr("改变当前配置"));
}
changeConfig::~changeConfig() {
    delete ui;
}

void changeConfig::load_json(QString json) {
    QFile file(json);
    if (!file.open(QIODevice::ReadOnly)) {
        QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::FILE_NOT_FOUND + ":" + json);
        return;
    }

    QJsonDocument doc = QJsonDocument::fromJson(file.readAll());
    file.close();

    if (doc.isNull() || !doc.isObject()) {
        QMessageBox::warning(this, "Error", "Invalid JSON format");
        return;
    }

    QJsonObject root = doc.object();

    // Load dataset settings
    if (root.contains("dataset")) {
        QJsonObject dataset = root["dataset"].toObject();

        if (dataset.contains("labels")) {
            QJsonArray labels = dataset["labels"].toArray();
            QString labelsStr;
            for (const QJsonValue& val : labels) {
                if (!labelsStr.isEmpty()) labelsStr += ",";
                labelsStr += QString::number(val.toInt());
            }
            ui->labels->setText(labelsStr);
        }

        if (dataset.contains("name")) {
            QString name = dataset["name"].toString();
            int idx = ui->dataset_name->findText(name);
            if (idx >= 0) ui->dataset_name->setCurrentIndex(idx);
        }

        if (dataset.contains("desired_shape")) {
            QJsonArray shape = dataset["desired_shape"].toArray();
            if (shape.size() >= 3) {
                ui->shape_x->setValue(shape[0].toInt());
                ui->shape_y->setValue(shape[1].toInt());
                ui->shape_z->setValue(shape[2].toInt());
            }
        }

        if (dataset.contains("setup_label_hierarchy")) {
            ui->setup_label_hierarchy->setChecked(dataset["setup_label_hierarchy"].toBool());
        }

        if (dataset.contains("normalization")) {
            QString norm = dataset["normalization"].toString();
            int idx = ui->normalization->findText(norm);
            if (idx >= 0) ui->normalization->setCurrentIndex(idx);
        }

        if (dataset.contains("normalization_kwargs")) {
            QJsonObject normKwargs = dataset["normalization_kwargs"].toObject();
            if (normKwargs.contains("channel_wise")) {
                ui->channel_wise->setChecked(normKwargs["channel_wise"].toBool());
            }
            if (normKwargs.contains("nonzero")) {
                ui->nonzero->setChecked(normKwargs["nonzero"].toBool());
            }
        }

        if (dataset.contains("resample")) {
            ui->resample->setChecked(dataset["resample"].toBool());
        }

        if (dataset.contains("crop_foreground")) {
            ui->crop_fore_ground->setChecked(dataset["crop_foreground"].toBool());
        }
    }

    // Load model settings
    if (root.contains("model")) {
        QJsonObject model = root["model"].toObject();

        if (model.contains("name")) {
            QString name = model["name"].toString();
            int idx = ui->model_name->findText(name);
            if (idx >= 0) ui->model_name->setCurrentIndex(idx);
        }

        if (model.contains("in_channels")) {
            bool independent = true;
            if (!cache_dir.isEmpty()) {
                QSettings cache(cache_dir, QSettings::IniFormat);
                independent = cache.value("independent", true).toBool();
            }
            if (independent && model["in_channels"].toInt() == 1) {
                ui->in_channels->setEnabled(false);
                ui->in_channels->setValue(1);
            }
            else ui->in_channels->setValue(model["in_channels"].toInt());
        }

        if (model.contains("out_channels")) {
            ui->out_channels->setValue(model["out_channels"].toInt());
        }

        if (model.contains("deep_supervision")) {
            ui->deep_supervision->setChecked(model["deep_supervision"].toBool());
        }

        if (model.contains("spatial_dims")) {
            ui->spatial_dims->setValue(model["spatial_dims"].toInt());
        }

        if (model.contains("filters")) {
            QJsonArray filters = model["filters"].toArray();
            ui->depth->setValue(filters.size());
        }
    }

    // Load optimizer settings
    if (root.contains("optimizer")) {
        QJsonObject optimizer = root["optimizer"].toObject();

        if (optimizer.contains("name")) {
            QString name = optimizer["name"].toString();
            int idx = ui->optimizer_name->findText(name);
            if (idx >= 0) ui->optimizer_name->setCurrentIndex(idx);
        }

        if (optimizer.contains("lr")) {
            QString lr = optimizer["lr"].toString();
            if (lr.startsWith("1e-")) {
                ui->lr_rate->setValue(lr.mid(3).toInt());
            }
        }
    }

    // Load loss settings
    if (root.contains("loss")) {
        QJsonObject loss = root["loss"].toObject();

        if (loss.contains("name")) {
            QString name = loss["name"].toString();
            int idx = ui->loss_name->findText(name);
            if (idx >= 0) ui->loss_name->setCurrentIndex(idx);
        }

        if (loss.contains("include_background")) {
            ui->include_background->setChecked(loss["include_background"].toBool());
        }

        if (loss.contains("softmax") && loss["softmax"].toBool()) {
            ui->activation->setCurrentText("softmax");
        }
        else if (loss.contains("sigmoid") && loss["sigmoid"].toBool()) {
            ui->activation->setCurrentText("sigmoid");
        }
    }

    // Load scheduler settings
    if (root.contains("scheduler")) {
        QJsonObject scheduler = root["scheduler"].toObject();

        if (scheduler.contains("name")) {
            QString name = scheduler["name"].toString();
            int idx = ui->scheduler_name->findText(name);
            if (idx >= 0) ui->scheduler_name->setCurrentIndex(idx);
        }

        if (scheduler.contains("patience")) {
            ui->patience->setValue(scheduler["patience"].toInt());
        }

        if (scheduler.contains("factor")) {
            ui->lineEdit->setText(QString::number(scheduler["factor"].toDouble()));
        }

        if (scheduler.contains("min_lr")) {
            QString minLr = scheduler["min_lr"].toString();
            if (minLr.startsWith("1e-")) {
                ui->min_learning_rate->setValue(minLr.mid(3).toInt());
            }
        }
    }

    // Load training settings
    if (root.contains("training")) {
        QJsonObject training = root["training"].toObject();

        if (training.contains("n_epochs")) {
            ui->n_epochs->setValue(training["n_epochs"].toInt());
        }

        if (training.contains("batch_size")) {
            ui->batch_size->setValue(training["batch_size"].toInt());
        }

        if (training.contains("validation_batch_size")) {
            ui->validation_batch_size->setValue(training["validation_batch_size"].toInt());
        }

        if (training.contains("amp")) {
            ui->amp->setChecked(training["amp"].toBool());
        }

        if (training.contains("early_stopping_patience")) {
            if (training["early_stopping_patience"].isNull()) {
                ui->early_stopping_patience->setValue(0);
            }
            else {
                ui->early_stopping_patience->setValue(training["early_stopping_patience"].toInt());
            }
        }

        if (training.contains("save_every_n_epochs")) {
            if (!training["save_every_n_epochs"].isNull()) {
                ui->save_every_n_epochs->setValue(training["save_every_n_epochs"].toInt());
            }
        }

        if (training.contains("save_last_n_models")) {
            if (!training["save_last_n_models"].isNull()) {
                ui->save_last_n_models->setValue(training["save_last_n_models"].toInt());
            }
        }

        if (training.contains("save_best")) {
            ui->save_best->setChecked(training["save_best"].toBool());
        }
    }
}

void changeConfig::btn_ok_clicked() {
    QFile file(json);
    if (!file.open(QIODevice::ReadWrite)) {
        QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::FILE_NOT_FOUND + ":" + json);
        return;
    }

    QJsonDocument doc = QJsonDocument::fromJson(file.readAll());
    if (doc.isNull() || !doc.isObject()) {
        QMessageBox::warning(this, messageConstants::ERROR_TITLE, "Invalid JSON format");
        file.close();
        return;
    }

    QJsonObject root = doc.object();

    // Update dataset settings
    QJsonObject dataset = root["dataset"].toObject();

    QString labelsText = ui->labels->text();
    QJsonArray labelsArray;
    QStringList labelParts = labelsText.split(",", Qt::SkipEmptyParts);
    for (const QString& part : labelParts) {
        labelsArray.append(part.trimmed().toInt());
    }
    dataset["labels"] = labelsArray;
    dataset["name"] = ui->dataset_name->currentText();

    QJsonArray shapeArray;
    shapeArray.append(ui->shape_x->value());
    shapeArray.append(ui->shape_y->value());
    shapeArray.append(ui->shape_z->value());
    dataset["desired_shape"] = shapeArray;

    dataset["setup_label_hierarchy"] = ui->setup_label_hierarchy->isChecked();
    dataset["normalization"] = ui->normalization->currentText();

    QJsonObject normKwargs = dataset["normalization_kwargs"].toObject();
    normKwargs["channel_wise"] = ui->channel_wise->isChecked();
    normKwargs["nonzero"] = ui->nonzero->isChecked();
    dataset["normalization_kwargs"] = normKwargs;

    dataset["resample"] = ui->resample->isChecked();
    dataset["crop_foreground"] = ui->crop_fore_ground->isChecked();
    root["dataset"] = dataset;

    // Update model settings
    QJsonObject model = root["model"].toObject();
    model["name"] = ui->model_name->currentText();
    model["in_channels"] = ui->in_channels->value();
    model["out_channels"] = ui->out_channels->value();
    model["deep_supervision"] = ui->deep_supervision->isChecked();
    model["spatial_dims"] = ui->spatial_dims->value();

    int depth = ui->depth->value();

    QJsonArray strides;
    QJsonArray stride1;
    stride1.append(1);
    stride1.append(1);
    stride1.append(1);
    strides.append(stride1);
    for (int i = 1; i < depth; i++) {
        QJsonArray strideN;
        strideN.append(2);
        strideN.append(2);
        strideN.append(2);
        strides.append(strideN);
    }
    model["strides"] = strides;

    QJsonArray filters;
    int filterVal = 64;
    for (int i = 0; i < depth; i++) {
        filters.append(filterVal);
        filterVal = static_cast<int>(filterVal * 1.5);
    }
    model["filters"] = filters;

    QJsonArray kernelSize;
    for (int i = 0; i < depth; i++) {
        QJsonArray kernel;
        kernel.append(3);
        kernel.append(3);
        kernel.append(3);
        kernelSize.append(kernel);
    }
    model["kernel_size"] = kernelSize;

    QJsonArray upsampleKernelSize;
    for (int i = 0; i < depth - 1; i++) {
        QJsonArray upsample;
        upsample.append(2);
        upsample.append(2);
        upsample.append(2);
        upsampleKernelSize.append(upsample);
    }
    model["upsample_kernel_size"] = upsampleKernelSize;

    root["model"] = model;

    // Update optimizer settings
    QJsonObject optimizer = root["optimizer"].toObject();
    optimizer["name"] = ui->optimizer_name->currentText();
    optimizer["lr"] = qPow(10.0, -ui->lr_rate->value());
    root["optimizer"] = optimizer;

    // Update loss settings
    QJsonObject loss = root["loss"].toObject();
    loss["name"] = ui->loss_name->currentText();
    loss["include_background"] = ui->include_background->isChecked();

    QString activation = ui->activation->currentText();
    if (activation == "softmax") {
        loss["softmax"] = true;
    }
    else if (activation == "sigmoid") {
        loss["sigmoid"] = true;
    }

    root["loss"] = loss;

    // Update scheduler settings
    QJsonObject scheduler = root["scheduler"].toObject();
    scheduler["name"] = ui->scheduler_name->currentText();
    scheduler["patience"] = ui->patience->value();
    scheduler["factor"] = ui->lineEdit->text().toDouble();
    scheduler["min_lr"] = qPow(10.0, -ui->min_learning_rate->value());
    root["scheduler"] = scheduler;

    // Update training settings
    QJsonObject training = root["training"].toObject();
    training["n_epochs"] = ui->n_epochs->value();
    training["batch_size"] = ui->batch_size->value();
    training["validation_batch_size"] = ui->validation_batch_size->value();
    training["amp"] = ui->amp->isChecked();

    int earlyStop = ui->early_stopping_patience->value();
    if (earlyStop == 0) {
        training["early_stopping_patience"] = QJsonValue::Null;
    }
    else {
        training["early_stopping_patience"] = earlyStop;
    }

    int saveEvery = ui->save_every_n_epochs->value();
    training["save_every_n_epochs"] = saveEvery > 0 ? QJsonValue(saveEvery) : QJsonValue::Null;

    int saveLast = ui->save_last_n_models->value();
    training["save_last_n_models"] = saveLast > 0 ? QJsonValue(saveLast) : QJsonValue::Null;

    training["save_best"] = ui->save_best->isChecked();
    root["training"] = training;

    // Write back to file
    file.resize(0);
    file.write(QJsonDocument(root).toJson(QJsonDocument::Indented));
    file.close();

    this->accept();
}

void changeConfig::btn_cancel_clicked() {
    this->reject();
}

void changeConfig::btn_show_all_settings_clicked(Qt::CheckState is_checked) {
    if (is_checked) advanced_settings(true);
    else advanced_settings(false);
}

void changeConfig::advanced_settings(bool is_show) {
    if (!is_show) {
        this->setFixedSize(510, 230);
        ui->model->hide();
        ui->optimizer->hide();
        ui->loss->hide();
        ui->cross_validation->hide();
        ui->scheduler->hide();
        ui->dataset->hide();
        ui->training->hide();
    }
    else {
        this->setFixedSize(510, 800);
        ui->model->show();
        ui->optimizer->show();
        ui->loss->show();
        ui->cross_validation->show();
        ui->scheduler->show();
        ui->dataset->show();
        ui->training->show();
    }
}