#include "changeLang.h"

changeLang::changeLang(QWidget *parent)
    : QDialog{parent},ui(new Ui::changeLang)
{
    ui->setupUi(this);
    connect(ui->btn_ok, &QPushButton::clicked, this, &changeLang::on_btn_ok_clicked);
    connect(ui->btn_cancel, &QPushButton::clicked, this, &changeLang::on_btn_cancel_clicked);
}

changeLang::~changeLang() {
    delete ui;
}

void changeLang::on_btn_ok_clicked() {
    QString lang = ui->lang->currentText();
    if (lang == "简体中文") {
        emit lang_change(":/translations/HIL_zh_CN.qm");
    }
    else {
        emit lang_change(":/translations/HIL_en.qm");
    }
    this->close();
}

void changeLang::on_btn_cancel_clicked() {
    this->close();
}
