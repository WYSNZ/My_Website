#include "manageDatasets.h"

manageDatasets::manageDatasets(QWidget* parent, QString dataset_root_dir, QStringList img_dirs, QString label_dir, QString project_dir, bool independent_input)
    : QDialog{ parent }, ui(new Ui::manageDatasets) {
    ui->setupUi(this);
    this->dataset_root_dir = dataset_root_dir;
    this->img_dirs = img_dirs;
    this->label_dir = label_dir;
    this->project_dir = project_dir;
    this->independent_input = independent_input;
    on_btn_refresh_clicked();
    connect(ui->treeWidget, &QTreeWidget::itemChanged, this, &manageDatasets::on_check_changed);
    connect(ui->btn_refresh, &QPushButton::clicked, this, &manageDatasets::on_btn_refresh_clicked);
    connect(ui->btn_ok, &QPushButton::clicked, this, &manageDatasets::on_btn_ok_clicked);

    this->setWindowTitle(tr("管理数据集"));
}

manageDatasets::~manageDatasets() {
    delete ui;
}

void manageDatasets::load_all_datasets() {
    if (dataset_root_dir.isEmpty()) return;
    QDir root_dir(dataset_root_dir);
    root_dir.setFilter(QDir::Dirs | QDir::NoDotAndDotDot);
    QFileInfoList datasets = root_dir.entryInfoList();
    for (QFileInfo dataset : datasets) {
        if (!check_imgs(dataset.absoluteFilePath())) continue;
        QTreeWidgetItem* root = new QTreeWidgetItem(ui->treeWidget);
        root->setText(0, dataset.fileName());
        root->setFlags(root->flags() | Qt::ItemIsUserCheckable);
        root->setData(0, Qt::UserRole, dataset.absoluteFilePath());
        add_img_nodes(root, dataset.absoluteFilePath());
        
    }
    update_parent_state();
}

bool manageDatasets::check_imgs(QString folder_path) {
    if (independent_input) {
        for (QString img_dir : img_dirs) {
            if (QFileInfo(folder_path + QDir::separator() + img_dir).exists()) return true;
        }
        return false;
    }
    else {
        for (QString img_dir : img_dirs) {
            if (!QFileInfo(folder_path + QDir::separator() + img_dir).exists()) return false;
        }
        return true;
    }
}

void manageDatasets::add_img_nodes(QTreeWidgetItem* root, QString dataset) {
    for (QString img_dir : img_dirs) {
        QFileInfo info_img(dataset + QDir::separator() + img_dir);
        if (info_img.exists()) {
            QTreeWidgetItem* child = new QTreeWidgetItem(root);
            child->setText(0, info_img.fileName());
            if (independent_input) {
                child->setFlags(child->flags() | Qt::ItemIsUserCheckable);
                if (check_dataset_is_added(QFileInfo(dataset).absoluteFilePath(), info_img.absoluteFilePath())) {
                    child->setCheckState(0, Qt::Checked);
                }
                else {
                    child->setCheckState(0, Qt::Unchecked);
                }
                child->setData(0, Qt::UserRole, info_img.absoluteFilePath());
            }

        }
    }
}

bool manageDatasets::check_dataset_is_added(QString dataset, QString img_dir) {
    QString name = QFileInfo(dataset).absoluteFilePath().split("/").last();
    QSqlQuery query;
    query.prepare("SELECT img_dir FROM files WHERE name=?");
    query.addBindValue(name);
    if (!query.exec()) {
        QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::DATABASE_ERROR + ":EXEC_FAIL");
        return false;
    }
    if (!query.next()) {
        return false;
    }
    QStringList images = query.value(0).toString().split(";");
    if (images.contains(img_dir)) return true;
    return false;
}

void manageDatasets::on_check_changed(QTreeWidgetItem* item, int column) {
    if (item->childCount() == 0) {
        bool checked = item->checkState(0);
        handle_child_change(item, checked);
        update_parent_state(item);
    }
    else {
        if (independent_input) {
            Qt::CheckState state = item->checkState(0);
            for (int i = 0;i < item->childCount();++i) {
                QTreeWidgetItem* child = item->child(i);
                if (child->checkState(0) != state) {
                    child->setCheckState(0, state);
                }
            }
        }
        else {
            handle_dependent_input(item);
        }
    }
}

void manageDatasets::handle_child_change(QTreeWidgetItem* child, bool checked) {
    QString name = QFileInfo(child->data(0, Qt::UserRole).toString()).absolutePath().split("/").last();
    if (checked) {
        // handle database io
        QSqlQuery query;
        query.prepare("SELECT img_dir,annotated FROM files WHERE name=?");
        query.addBindValue(name);
        QString part;
        if (!query.exec()) {
            QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::DATABASE_ERROR + ":EXEC_FAIL");
            return;
        }
        if (query.next()) {
            QString imgs = query.value(0).toString();
            int annotated = query.value(1).toInt();
            if (annotated == 0) part = "rest_filenames";
            else if (annotated == 1) part = "training_filenames";
            else if (annotated == 2) part = "prediction_filenames";
            imgs += ";";
            imgs += child->data(0, Qt::UserRole).toString();
            query.prepare("UPDATE files SET img_dir=? WHERE name=?");
            query.addBindValue(imgs);
            query.addBindValue(name);
            if (!query.exec()) {
                QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::DATABASE_ERROR + ":EXEC_FAIL");
                return;
            }
        }
        else {
            query.prepare("INSERT INTO files (name,img_dir,label_dir) VALUES (?,?,?)");
            query.addBindValue(name);
            query.addBindValue(child->data(0, Qt::UserRole).toString());
            query.addBindValue("");
            part = "rest_filenames";
            if (!query.exec()) {
                QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::DATABASE_ERROR + ":EXEC_FAIL");
                return;
            }
        }


        //handle json file
        QFile json_file(project_dir + "/config.json");
        if (!json_file.open(QIODevice::ReadWrite)) {
            QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::CONFIG_ERROR + project_dir + "/config.json");
            return;
        }
        QJsonDocument doc = QJsonDocument::fromJson(json_file.readAll());
        QJsonObject root = doc.object();
        QJsonArray rest = root[part].toArray();
        QJsonArray image_array;
        image_array.append(child->data(0, Qt::UserRole).toString());
        QJsonObject obj;
        obj["image"] = image_array;
        if (part == "training_filenames") obj["label"] = QFileInfo(child->data(0, Qt::UserRole).toString()).absolutePath() + "/" + label_dir;
        rest.append(obj);
        root[part] = rest;
        doc.setObject(root);
        json_file.resize(0);
        json_file.write(doc.toJson());
        json_file.close();
    }
    else {
        QSqlQuery query;
        query.prepare("SELECT img_dir,annotated FROM files WHERE name=?");
        query.addBindValue(name);
        if (!query.exec()) {
            QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::DATABASE_ERROR + ":EXEC_FAIL");
            return;
        }
        if (!query.next()) {
            QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::DATABASE_ERROR + ":EXEC_FAIL");
            return;
        }
        QString imgs = query.value(0).toString();
        int status = query.value(1).toInt();
        QStringList list = imgs.split(";");
        list.removeAll(child->data(0, Qt::UserRole).toString());
        imgs = list.join(";");
        if (imgs.isEmpty()) {
            query.prepare("DELETE FROM files WHERE name=?");
            query.addBindValue(name);
            if (!query.exec()) {
                QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::DATABASE_ERROR + ":EXEC_FAIL");
                return;
            }
        }
        else {
            query.prepare("UPDATE files SET img_dir=? WHERE name=?");
            query.addBindValue(imgs);
            query.addBindValue(name);
            if (!query.exec()) {
                QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::DATABASE_ERROR + ":EXEC_FAIL");
                return;
            }
        }
        QString del;
        if (status == 0) del = "rest_filenames";
        else if (status == 1) del = "training_filenames";
        else if (status == 2) del = "prediction_filenames";
        else {
            QMessageBox::warning(this, messageConstants::ERROR_TITLE, "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            return;
        }
        QFile json_file(project_dir + "/config.json");
        if (!json_file.open(QIODevice::ReadWrite)) {
            QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::CONFIG_ERROR + project_dir + "/config.json");
            return;
        }
        QJsonDocument doc = QJsonDocument::fromJson(json_file.readAll());
        QJsonObject root = doc.object();
        QJsonArray ds = root[del].toArray();
        for (int i = 0;i < ds.size();++i) {
            QJsonObject obj = ds[i].toObject();
            QJsonArray arr = obj["image"].toArray();
            if (arr.isEmpty()) continue;
            if (QFileInfo(arr[0].toString()).absoluteFilePath() == child->data(0, Qt::UserRole).toString()) {
                ds.removeAt(i);
                break;
            }
        }
        root[del] = ds;
        doc.setObject(root);
        json_file.resize(0);
        json_file.write(doc.toJson());
        json_file.close();
    }
}

void manageDatasets::update_parent_state(QTreeWidgetItem* child) {
    ui->treeWidget->blockSignals(true);
    QTreeWidgetItem* parent = child->parent();
    int checked_cnt = 0;
    for (int i = 0;i < parent->childCount();++i) {
        QTreeWidgetItem* item = parent->child(i);
        if (item->checkState(0) == Qt::Checked) {
            checked_cnt++;
        }
    }
    if (checked_cnt == parent->childCount()) parent->setCheckState(0, Qt::Checked);
    else if (checked_cnt == 0) parent->setCheckState(0, Qt::Unchecked);
    else parent->setCheckState(0, Qt::PartiallyChecked);
    ui->treeWidget->blockSignals(false);
}

void manageDatasets::update_parent_state() {
    ui->treeWidget->blockSignals(true);
    if (independent_input) {
        for (int i = 0;i < ui->treeWidget->topLevelItemCount();++i) {
            QTreeWidgetItem* parent = ui->treeWidget->topLevelItem(i);
            int checked_cnt = 0;
            for (int i = 0;i < parent->childCount();++i) {
                QTreeWidgetItem* item = parent->child(i);
                if (item->checkState(0) == Qt::Checked) {
                    checked_cnt++;
                }
            }
            if (checked_cnt == parent->childCount()) parent->setCheckState(0, Qt::Checked);
            else if (checked_cnt == 0) parent->setCheckState(0, Qt::Unchecked);
            else parent->setCheckState(0, Qt::PartiallyChecked);

        }
    }
    else {
        for (int i = 0;i < ui->treeWidget->topLevelItemCount();++i) {
            QTreeWidgetItem* parent = ui->treeWidget->topLevelItem(i);
            QString name = QFileInfo(parent->data(0, Qt::UserRole).toString()).fileName();

            QSqlQuery query;
            query.prepare("SELECT id FROM files WHERE name=?");
            query.addBindValue(name);
            if (!query.exec()) {
                QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::DATABASE_ERROR + ":EXEC_FAIL");
                continue;
            }

            parent->setCheckState(0, query.next() ? Qt::Checked : Qt::Unchecked);
        }
    }
    ui->treeWidget->blockSignals(false);
}

void manageDatasets::handle_dependent_input(QTreeWidgetItem* item) {
    ui->treeWidget->blockSignals(true);
    QString data = item->data(0, Qt::UserRole).toString();
    QString name = QFileInfo(data).baseName();
    bool checked = (item->checkState(0) == Qt::Checked);
    if (checked) {
        QString img_dir;
        for (QString _name : img_dirs) {
            if (!img_dir.isEmpty()) img_dir += ";";
            img_dir += data + "/" + _name;
        }
        add_dataset(name, img_dir);
    }
    else {
        delete_dataset(name);
    }
    ui->treeWidget->blockSignals(false);
}

void manageDatasets::add_dataset(QString name, QString img_dir) {
    QSqlQuery query;
    query.prepare("INSERT INTO files (name,img_dir,label_dir) VALUES (?,?,?)");
    query.addBindValue(name);
    query.addBindValue(img_dir);
    query.addBindValue("");
    if (!query.exec()) {
        QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::DATABASE_ERROR + ":EXEC_FIAL");
        return;
    }

    QFile json_file(project_dir + "/config.json");
    if (!json_file.open(QIODevice::ReadWrite)) {
        QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::CONFIG_ERROR + project_dir + "/config.json");
        return;
    }
    QJsonDocument doc = QJsonDocument::fromJson(json_file.readAll());
    QJsonObject root = doc.object();
    QJsonArray rest = root["rest_filenames"].toArray();

    QStringList parts = img_dir.split(";");
    QJsonArray image_array;
    for (QString part : parts) {
        image_array.append(part);
    }
    QJsonObject obj;
    obj["image"] = image_array;
    rest.append(obj);
    root["rest_filenames"] = rest;
    doc.setObject(root);
    json_file.resize(0);
    json_file.write(doc.toJson());
    json_file.close();
}

void manageDatasets::delete_dataset(QString name) {
    QSqlQuery query;
    query.prepare("SELECT annotated FROM files WHERE name=?");
    query.addBindValue(name);
    if (!query.exec()) {
        QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::DATABASE_ERROR + ":EXEC_FIAL");
        return;
    }
    int status = -1;
    if (query.next()) {
        status = query.value(0).toInt();
    }

    query.prepare("DELETE FROM files WHERE name=?");
    query.addBindValue(name);
    if (!query.exec()) {
        QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::DATABASE_ERROR + ":EXEC_FIAL");
        return;
    }

    QFile json_file(project_dir + "/config.json");
    if (!json_file.open(QIODevice::ReadWrite)) {
        QMessageBox::warning(this, messageConstants::ERROR_TITLE, messageConstants::CONFIG_ERROR + project_dir + "/config.json");
        return;
    }
    QJsonArray del;
    QString part;
    QJsonDocument doc = QJsonDocument::fromJson(json_file.readAll());
    QJsonObject root = doc.object();
    if (status == 0) {
        part = "rest_filenames";
    }
    else if (status == 1) {
        part = "training_filenames";
    }
    else if (status == 2) {
        part = "prediction_filenames";
    }
    else {
        QMessageBox::warning(this, messageConstants::ERROR_TITLE, tr("数据库内容异常"));
        return;
    }
    del = root[part].toArray();
    for (int i = 0;i < del.size();i++) {
        QJsonObject obj = del[i].toObject();
        QJsonArray arr = obj["image"].toArray();
        if (arr.isEmpty()) continue;
        QFileInfo info(arr[0].toString());
        if (info.absolutePath().split('/').last() == name) {
            del.removeAt(i);
            break;
        }
    }
    root[part] = del;
    doc.setObject(root);
    json_file.resize(0);
    json_file.write(doc.toJson());
    json_file.close();
}

void manageDatasets::on_btn_refresh_clicked() {
    ui->treeWidget->blockSignals(true);
    ui->treeWidget->clear();
    load_all_datasets();
    ui->treeWidget->blockSignals(false);
}

void manageDatasets::on_btn_ok_clicked() {
    this->close();
}
