#include "environmentControl.h"

environmentControl::environmentControl(QWidget* parent,QString cache_dir)
    : QDialog{ parent }, ui(new Ui::environmentControl) {
    ui->setupUi(this);
    this->setWindowTitle(tr("环境选择"));
    connect(ui->btn_env_browse, &QPushButton::clicked, this, &environmentControl::btn_browse_env_clicked);
    connect(ui->btn_itk_browse, &QPushButton::clicked, this, &environmentControl::btn_browse_itk_clicked);
    connect(ui->btn_ok, &QPushButton::clicked, this, &environmentControl::btn_ok_clicked);
    connect(ui->btn_skip, &QPushButton::clicked, this, &environmentControl::btn_skip_clicked);
    
    load_cache(cache_dir);
    if (python_env.isEmpty() || itk_snap_path.isEmpty()) {
            ui->btn_ok->setEnabled(false);
    }
}
environmentControl::~environmentControl() {
    delete ui;
}
void environmentControl::btn_browse_env_clicked() {
#ifdef Q_OS_WIN
    python_env = QFileDialog::getOpenFileName(this, DialogTitles::SELECT_PYTHON_ENV, QDir::homePath(), "Python Excutable (*.exe)");
#else
    python_env = QFileDialog::getOpenFileName(this, DialogTitles::SELECT_PYTHON_ENV, QDir::homePath(), "Python Executable (python python3)");
#endif
    ui->env_browse->setText(python_env);
    if (python_env.isEmpty()) return;

    QProgressDialog* waiting = new QProgressDialog("正在检测环境，请稍等...", "", 0, 0, this);
    waiting->setCancelButton(nullptr);
    waiting->setWindowTitle("请稍等");
    waiting->setWindowModality(Qt::WindowModal);
    waiting->setMinimumDuration(0);

    QProcess* check_env = new QProcess(this);
    QStringList args;
    args << QCoreApplication::applicationDirPath() + "/scripts/checkEnv.py" << "-u";
    check_env->start(python_env, args);
    connect(check_env, &QProcess::readyReadStandardError, this, [=]() {
        ui->val_browse->append(QString::fromLocal8Bit(check_env->readAllStandardError()));
        });
    connect(check_env, &QProcess::readyReadStandardOutput, this, [=]() {
        ui->val_browse->append(QString::fromLocal8Bit(check_env->readAllStandardOutput()));
        });
    connect(check_env, &QProcess::finished, this, [=]() {
        waiting->close();
        if (check_env->exitCode() == 0) {
            ui->val_browse->append("Python环境检测通过");
            ui->btn_ok->setEnabled(true);
        }
        else {
            ui->val_browse->append("Python环境检测未通过，请重试");
        }
        });
    connect(check_env, &QProcess::started, this, [=] {
        waiting->show();
        connect(check_env, &QProcess::finished, waiting, &QProgressDialog::deleteLater);
        connect(check_env, &QProcess::errorOccurred, waiting, &QProgressDialog::deleteLater);
        });
    QTimer::singleShot(30000, this, [=]() {
        if (check_env->state() == QProcess::Running) {
            ui->val_browse->append("进程超时，请重新选择环境");
            check_env->kill();
            check_env->deleteLater();
        }
        });
}

void environmentControl::closeEvent(QCloseEvent* event) {
    event->accept();
    this->reject();
}

void environmentControl::btn_browse_itk_clicked() {
#ifdef Q_OS_WIN
    itk_snap_path = QFileDialog::getOpenFileName(this,DialogTitles::SELECT_ITKSNAP, QDir::homePath(), "Excutable (*.exe)");
#else
    itk_snap_path = QFileDialog::getOpenFileName(this, DialogTitles::SELECT_ITKSNAP, QDir::homePath(), "Executable (itksnap)");
#endif
    if (!QFileInfo(itk_snap_path).exists()) {
        QMessageBox::warning(this, messageConstants::ERROR_TITLE,messageConstants::SELECT_VALID_FILE);
    }
    ui->itk_browse->setText(itk_snap_path);
    if (!python_env.isEmpty() && !itk_snap_path.isEmpty()) {
        ui->btn_ok->setEnabled(true);
    }
}

void environmentControl::btn_ok_clicked() {
    this->accept();
}

void environmentControl::load_cache(QString dir) {
    if (!QFileInfo(dir).exists()) return;
    QSettings cache(dir, QSettings::IniFormat, this);
    python_env = cache.value("Environment/python").toString();
    itk_snap_path = cache.value("Environment/itk_snap").toString();
    ui->env_browse->setText(python_env);
    ui->itk_browse->setText(itk_snap_path);
}

void environmentControl::btn_skip_clicked() {
    if (ui->env_browse->text().isEmpty() || ui->itk_browse->text().isEmpty()) {
        auto reply = QMessageBox::question(this, messageConstants::WARNING_TITLE, "存在未设置的环境变量，如果跳过可能会导致部分功能无法使用！\n如果检测到缓存文件内存在路径，会自动加载", QMessageBox::Ok | QMessageBox::No, QMessageBox::No);
        if (reply == QMessageBox::No) return;
    }
    this->accept();
}