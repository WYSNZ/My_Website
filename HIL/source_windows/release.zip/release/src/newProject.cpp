#include "newProject.h"

newProject::newProject(QWidget *parent,QString python_dir,QString cache_dir)
    : QDialog{parent},ui(new Ui::newProject),python_dir(python_dir),cache_dir(cache_dir)
{
    ui->setupUi(this);
    ui->btn_choose_exist->hide();//隐藏选择现有配置按钮
    connect(ui->btn_ok, &QPushButton::clicked, this, &newProject::btn_ok_clicked);
    connect(ui->btn_cancel, &QPushButton::clicked, this, &newProject::btn_cancel_clicked);
    connect(ui->btn_new_config, &QPushButton::clicked, this, &newProject::btn_new_config_clicked);
    // connect(ui->btn_choose_exist, &QPushButton::clicked, this, &newProject::btn_choose_exist_clicked);
    this->setWindowTitle(tr("新建项目"));
}
newProject::~newProject() {
    delete ui;
}

void newProject::btn_ok_clicked() {
    QString name = ui->projectName->text();
    if (name.isEmpty()) {
        QMessageBox::warning(this, messageConstants::ERROR_TITLE, "请输入项目名称");
        return;
    }
    projectName = name;
    this->accept();
}

void newProject::btn_cancel_clicked() {
    this->close();
}

void newProject::btn_new_config_clicked() {
    generateConfig* c = new generateConfig(this, python_dir, cache_dir);
    connect(c, &generateConfig::send_config_dir, this, [=](QString c_dir,QString l_name) {
        config = c_dir;
        ui->config_browser->setText(config);
        label_name = l_name;
        });
    c->load_cache(QCoreApplication::applicationDirPath() + "/cache.ini");
    c->exec();
    if (c->args.isEmpty()) return;
    QSettings cache(QCoreApplication::applicationDirPath() + "/cache.ini", QSettings::IniFormat, this);
    cache.setValue("args", c->args);
}

void newProject::btn_choose_exist_clicked() {
    config = QFileDialog::getOpenFileName(this, DialogTitles::SELECT_JSON_FILE, QDir::homePath(), "JSON File(*.json);;All Files(*.*)");
    ui->config_browser->setText(config);
    bool ok;
    QString name=QInputDialog::getText(this, tr("输入数据集的label名称"), tr("Label_name: "), QLineEdit::Normal, "", &ok);
    if (ok) {
        label_name = name;
    }
}